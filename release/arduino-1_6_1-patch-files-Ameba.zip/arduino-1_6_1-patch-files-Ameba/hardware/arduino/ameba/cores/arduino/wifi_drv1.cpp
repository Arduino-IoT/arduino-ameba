/*
  wifi_drv.cpp - Library for Arduino Wifi shield.
  Copyright (c) 2011-2014 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <stdio.h>
#include <string.h>
#include <stdint.h>

#include "variant.h"

#include "Arduino.h"
#include "wifi_drv1.h"

#include "wifi_intfs.h"


// Private Methods




// Public Methods


void WiFiDrv1::wifiDriverInit()
{

	rtw_wifi_init(&halData);

	Serial.print("ChipType = ");
	Serial.println(halData.ChipType);

	Serial.print("VendorType = ");
	Serial.println(halData.VendorType);

	Serial.print("CUTVersion = ");
	Serial.println(halData.CUTVersion);

	Serial.print("RegulatorMode = ");
	Serial.println(halData.RegulatorMode);

	Serial.print("MacControl = ");
	Serial.println(halData.bMacPwrCtrlOn);
	
	this->mlme_fw_state = WIFI_NULL_STATE;
	
	
}


int8_t WiFiDrv1::startScanNetworks()
{
#if 1
	Serial.println("WiFiDrv1.startScanNetworks()");

	uint8_t _data = 0;
	return (_data == WL_FAILURE)? _data : WL_SUCCESS;

#else
	WAIT_FOR_SLAVE_SELECT();

    // Send Command
    SpiDrv::sendCmd(START_SCAN_NETWORKS, PARAM_NUMS_0);

    //Wait the reply elaboration
    SpiDrv::waitForSlaveReady();

    // Wait for reply
    uint8_t _data = 0;
    uint8_t _dataLen = 0;

    if (!SpiDrv::waitResponseCmd(START_SCAN_NETWORKS, PARAM_NUMS_1, &_data, &_dataLen))
     {
         WARN("error waitResponse");
         _data = WL_FAILURE;
     }

    SpiDrv::spiSlaveDeselect();

    return (_data == WL_FAILURE)? _data : WL_SUCCESS;
#endif
}


uint8_t WiFiDrv1::getScanNetworks()
{
#if 1
	Serial.println("WiFiDrv1.getScanNetworks()");
	return 1;

#else
	WAIT_FOR_SLAVE_SELECT();

    // Send Command
    SpiDrv::sendCmd(SCAN_NETWORKS, PARAM_NUMS_0);

    //Wait the reply elaboration
    SpiDrv::waitForSlaveReady();

    // Wait for reply
    uint8_t ssidListNum = 0;
    SpiDrv::waitResponse(SCAN_NETWORKS, &ssidListNum, (uint8_t**)_networkSsid, WL_NETWORKS_LIST_MAXNUM);

    SpiDrv::spiSlaveDeselect();

    return ssidListNum;
#endif
}

char SSID_name[]="MyNetworks";

char* WiFiDrv1::getSSIDNetworks(uint8_t networkItem)
{
#if 1
	Serial.println("WiFiDrv1.getSSIDNetworks()");
	return SSID_name;
#else
	if (networkItem >= WL_NETWORKS_LIST_MAXNUM)
		return NULL;

	return _networkSsid[networkItem];
#endif
}

uint8_t WiFiDrv1::getEncTypeNetworks(uint8_t networkItem)
{
#if 1
	Serial.println("WiFiDrv1.getEncTypeNetworks()");
	return 1;

#else
	if (networkItem >= WL_NETWORKS_LIST_MAXNUM)
		return NULL;

	WAIT_FOR_SLAVE_SELECT();

    // Send Command
    SpiDrv::sendCmd(GET_IDX_ENCT_CMD, PARAM_NUMS_1);

    SpiDrv::sendParam(&networkItem, 1, LAST_PARAM);

    //Wait the reply elaboration
    SpiDrv::waitForSlaveReady();

    // Wait for reply
    uint8_t dataLen = 0;
    uint8_t encType = 0;
    SpiDrv::waitResponseCmd(GET_IDX_ENCT_CMD, PARAM_NUMS_1, (uint8_t*)&encType, &dataLen);

    SpiDrv::spiSlaveDeselect();

    return encType;
#endif
		
}

int32_t WiFiDrv1::getRSSINetworks(uint8_t networkItem)
{
#if 1

	Serial.println("WiFiDrv1.getRSSINetworks()");
	return 1;

#else
	if (networkItem >= WL_NETWORKS_LIST_MAXNUM)
		return NULL;
	int32_t	networkRssi = 0;

	WAIT_FOR_SLAVE_SELECT();

    // Send Command
    SpiDrv::sendCmd(GET_IDX_RSSI_CMD, PARAM_NUMS_1);

    SpiDrv::sendParam(&networkItem, 1, LAST_PARAM);

    //Wait the reply elaboration
    SpiDrv::waitForSlaveReady();

    // Wait for reply
    uint8_t dataLen = 0;
    SpiDrv::waitResponseCmd(GET_IDX_RSSI_CMD, PARAM_NUMS_1, (uint8_t*)&networkRssi, &dataLen);

    SpiDrv::spiSlaveDeselect();

	return networkRssi;
#endif
}



WiFiDrv1 wiFiDrv1;

