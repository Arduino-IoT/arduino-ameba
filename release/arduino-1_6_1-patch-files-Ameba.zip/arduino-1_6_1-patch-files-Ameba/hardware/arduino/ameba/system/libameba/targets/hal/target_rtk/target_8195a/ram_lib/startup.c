/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2013 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */

#include "rtl8195a.h"
#include "build_info.h"
#ifdef PLATFORM_FREERTOS
#include "FreeRTOS.h"
#include "task.h"
#endif

#define IMG2_FLASH_ADDR         0x6000

#if defined ( __ICCARM__ )
#pragma section=".ram.bss"
#pragma section=".rom.bss"
#pragma section=".ram.start.table"
#pragma section=".ram_image1.bss"
#pragma section=".image2.start.table1"
#pragma section=".image2.start.table2"

u8* __bss_start__;
u8* __bss_end__;
u8* __image2_entry_func__;
u8* __image2_validate_code__;
u8* __image1_bss_start__;
u8* __image1_bss_end__;
//extern u8* __rom_bss_start__;
//extern u8* __rom_bss_end__;
//extern u8* __ram_start_table_start__;

void __iar_data_init3(void)
{
    // only need __bss_start__, __bss_end__
    __bss_start__               = (u8*)__section_begin(".ram.bss");
    __bss_end__                 = (u8*)__section_end(".ram.bss");
    __image2_entry_func__		= (u8*)__section_begin(".image2.start.table1");
	__image2_validate_code__	= (u8*)__section_begin(".image2.start.table2");
	__image1_bss_start__		= (u8*)__section_begin(".ram_image1.bss");
	__image1_bss_end__			= (u8*)__section_end(".ram_image1.bss");
    // __rom_bss_start__, __rom_bss_end__, __ram_start_table_start__
    // are fixed address in rom code. NO need to setup
    //__rom_bss_start__           = (u8*)__section_begin(".rom.bss");
    //__rom_bss_end__             = (u8*)__section_end(".rom.bss");
    //__ram_start_table_start__   = (u8*)__section_begin(".ram.start.table");
}
#else
extern u8 __bss_start__[];
extern u8 __bss_end__[];
extern u8 __image2_entry_func__[];
extern u8 __image2_validate_code__[];
extern u8 __image1_bss_start__[];
extern u8 __image1_bss_end__[];
#endif

#ifdef CONFIG_TIMER_MODULE
extern HAL_TIMER_OP        HalTimerOp;
#endif

extern VOID UartLogIrqHandle(VOID* Data);

extern _WEAK VOID InfraStart(VOID);// __attribute__ ((weak));

#if defined(CONFIG_KERNEL) && defined(PLATFORM_FREERTOS)
extern void vTaskStartScheduler( void );
#endif

#ifdef CONFIG_KERNEL
extern void vPortSVCHandler( void );
extern void xPortPendSVHandler( void );
extern void xPortSysTickHandler( void );
#endif

VOID PreProcessForVendor(VOID);
extern VOID HalCpuClkConfig(IN  u8  CpuType);
extern void SystemCoreClockUpdate (void);
extern u32 HalGetCpuClk(VOID);
extern u32 SdrControllerInit(VOID);
extern VOID ShowRamBuildInfo(VOID);
extern void _AppStart(void);

#if CONFIG_BOOT_FROM_JTAG
void RtlBootToSram(VOID);
START_RAM_FUN_A_SECTION
RAM_START_FUNCTION gRamStartFun = {PreProcessForVendor};

START_RAM_FUN_B_SECTION
RAM_START_FUNCTION gRamPatchWAKE = {RtlBootToSram};

START_RAM_FUN_C_SECTION
RAM_START_FUNCTION gRamPatchFun0 = {RtlBootToSram};

START_RAM_FUN_D_SECTION
RAM_START_FUNCTION gRamPatchFun1 = {RtlBootToSram};

START_RAM_FUN_E_SECTION
RAM_START_FUNCTION gRamPatchFun2 = {RtlBootToSram};

#elif CONFIG_COMPILE_FLASH_DOWNLOAD_CODE
void RtlFlashProgram(VOID);

START_RAM_FUN_A_SECTION
RAM_START_FUNCTION gRamStartFun = {PreProcessForVendor};

START_RAM_FUN_B_SECTION
RAM_START_FUNCTION gRamPatchWAKE = {RtlFlashProgram};

START_RAM_FUN_C_SECTION
RAM_START_FUNCTION gRamPatchFun0 = {RtlFlashProgram};

START_RAM_FUN_D_SECTION
RAM_START_FUNCTION gRamPatchFun1 = {RtlFlashProgram};

START_RAM_FUN_E_SECTION
RAM_START_FUNCTION gRamPatchFun2 = {RtlFlashProgram};

#else
START_RAM_FUN_A_SECTION
RAM_START_FUNCTION gRamStartFun = {PreProcessForVendor};
#ifndef CONFIG_SOC_PS_MODULE
START_RAM_FUN_B_SECTION
RAM_START_FUNCTION gRamPatchWAKE = {PreProcessForVendor};
#endif
START_RAM_FUN_C_SECTION
RAM_START_FUNCTION gRamPatchFun0 = {PreProcessForVendor};

START_RAM_FUN_D_SECTION
RAM_START_FUNCTION gRamPatchFun1 = {PreProcessForVendor};

START_RAM_FUN_E_SECTION
RAM_START_FUNCTION gRamPatchFun2 = {PreProcessForVendor};
#endif

IMAGE2_START_RAM_FUN_SECTION
RAM_START_FUNCTION gImage2EntryFun0 = {InfraStart};

IMAGE1_VALID_PATTEN_SECTION const u8 RAM_IMG1_VALID_PATTEN[] = {
    0x23, 0x79, 0x16, 0x88, 0xff, 0xff, 0xff, 0xff
};

IMAGE2_VALID_PATTEN_SECTION const u8 RAM_IMG2_VALID_PATTEN[] = {
    'R', 'T', 'K', 'W', 'i', 'n', 0x0, 0xff, 
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
};

extern u32 ConfigDebugErr;
extern u32 ConfigDebugInfo;
extern u32 ConfigDebugWarn;

static 
HAL_RAM_TEXT_SECTION
VOID
StartupHalInitialROMCodeGlobalVar(VOID)
{
    // to initial ROM code using global variable
    ConfigDebugErr = 0xFFFFFFFF;//_DBG_MISC_;]
    ConfigDebugInfo = 0xFFFFFFFF;
    ConfigDebugWarn = 0xFFFFFFFF;
}

#if CONFIG_CHIP_A_CUT
const INFRA_RAM_TEXT_SECTION u32 StartupCpkClkTbl[]= {
    200000000,
    100000000,
    50000000,
    25000000,
    12500000,
    4000000
};


u32
HAL_RAM_TEXT_SECTION
StartupHalGetCpuClk(
    VOID
)
{
    u32  CpuType = 0, CpuClk = 0, FreqDown = 0;

    CpuType = ((HAL_READ32(SYSTEM_CTRL_BASE, REG_SYS_CLK_CTRL1) & (0x70)) >> 4);
    FreqDown = HAL_READ32(SYSTEM_CTRL_BASE, REG_SYS_SYSPLL_CTRL1) & BIT17;

    CpuClk = StartupCpkClkTbl[CpuType];

    if ( !FreqDown ) {
        if ( CpuClk > 4000000 ){
            CpuClk = (CpuClk*5/6);
        }
    }

    return CpuClk;
}
#endif

static 
HAL_RAM_TEXT_SECTION
u32 
StartupHalLogUartInit(
    IN  LOG_UART_ADAPTER    UartAdapter
)
{
    u32 SetData;
    u32 Divisor;
    u32 Dlh;
    u32 Dll;
    u32 SysClock;

    /*
        Interrupt enable Register
        7: THRE Interrupt Mode Enable
        2: Enable Receiver Line Status Interrupt
        1: Enable Transmit Holding Register Empty Interrupt
        0: Enable Received Data Available Interrupt
        */
    // disable all interrupts
    HAL_UART_WRITE32(UART_INTERRUPT_EN_REG_OFF, 0);

    /*
        Line Control Register
        7:   DLAB, enable reading and writing DLL and DLH register, and must be cleared after
        initial baud rate setup
        3:   PEN, parity enable/disable
        2:   STOP, stop bit
        1:0  DLS, data length
        */

    // set DLAB bit to 1
    HAL_UART_WRITE32(UART_LINE_CTL_REG_OFF, 0x80);

    // set up buad rate division 

#ifdef CONFIG_FPGA        
    SysClock = SYSTEM_CLK;
#else    
{
    u32 SampleRate,Remaind;
    
    #if CONFIG_CHIP_A_CUT
    SysClock = (StartupHalGetCpuClk()>>2);
    #else CONFIG_CHIP_B_CUT
    SysClock = (HalGetCpuClk()>>2);
    #endif
    SampleRate = (16 * (UartAdapter.BaudRate));
    
    Divisor= SysClock/SampleRate;
    
    Remaind = ((SysClock*10)/SampleRate) - (Divisor*10);
    
    if (Remaind>4) {
        Divisor++;
    }  
}
#endif    


    Dll = Divisor & 0xff;
    Dlh = (Divisor & 0xff00)>>8;
    HAL_UART_WRITE32(UART_DLL_OFF, Dll);
    HAL_UART_WRITE32(UART_DLH_OFF, Dlh);

    // clear DLAB bit 
    HAL_UART_WRITE32(UART_LINE_CTL_REG_OFF, 0);

    // set data format
    SetData = UartAdapter.Parity | UartAdapter.Stop | UartAdapter.DataLength;
    HAL_UART_WRITE32(UART_LINE_CTL_REG_OFF, SetData);

    /* FIFO Control Register
        7:6  level of receive data available interrupt
        5:4  level of TX empty trigger
        2    XMIT FIFO reset
        1    RCVR FIFO reset
        0    FIFO enable/disable
        */
    // FIFO setting, enable FIFO and set trigger level (2 less than full when receive
    // and empty when transfer 
    HAL_UART_WRITE32(UART_FIFO_CTL_REG_OFF, UartAdapter.FIFOControl);

    /*
        Interrupt Enable Register
        7: THRE Interrupt Mode enable
        2: Enable Receiver Line status Interrupt
        1: Enable Transmit Holding register empty INT32
        0: Enable received data available interrupt
        */
    HAL_UART_WRITE32(UART_INTERRUPT_EN_REG_OFF, UartAdapter.IntEnReg);

    if (UartAdapter.IntEnReg) {
        // Enable Peripheral_IRQ Setting for Log_Uart
        HAL_WRITE32(VENDOR_REG_BASE, PERIPHERAL_IRQ_EN, 0x1000000);

        // Enable ARM Cortex-M3 IRQ
        NVIC_SetPriorityGrouping(0x3);
        NVIC_SetPriority(PERIPHERAL_IRQ, 14);
        NVIC_EnableIRQ(PERIPHERAL_IRQ);
    }   

    return 0;
}


static 
HAL_RAM_TEXT_SECTION
VOID
StartupHalInitPlatformLogUart(
    VOID
)
{
    IRQ_HANDLE          UartIrqHandle;
    LOG_UART_ADAPTER    UartAdapter;
    
    //4 Release log uart reset and clock
    LOC_UART_FCTRL(OFF);
    LOC_UART_FCTRL(ON);
    ACTCK_LOG_UART_CCTRL(ON);
    //PinCtrl(LOG_UART,S0,ON);

    //4 Register Log Uart Callback function
    UartIrqHandle.Data = (u32)NULL;//(u32)&UartAdapter;
    UartIrqHandle.IrqNum = UART_LOG_IRQ;
    UartIrqHandle.IrqFun = (IRQ_FUN) UartLogIrqHandle;
    UartIrqHandle.Priority = 0;

    //4 Inital Log uart
    UartAdapter.BaudRate = UART_BAUD_RATE_38400;
    UartAdapter.DataLength = UART_DATA_LEN_8BIT;
    UartAdapter.FIFOControl = 0xC1;
    UartAdapter.IntEnReg = 0x05;///0x00;
    UartAdapter.Parity = UART_PARITY_DISABLE;
    UartAdapter.Stop = UART_STOP_1BIT;

    //4 Initial Log Uart
    StartupHalLogUartInit(UartAdapter);
}

 
#ifdef CONFIG_TIMER_MODULE
static 
HAL_RAM_TEXT_SECTION
VOID
StartupHalInitPlatformTimer(
VOID
)
{
    TIMER_ADAPTER       TimerAdapter;

    HAL_WRITE32(SYSTEM_CTRL_BASE, 0x204, 0x3);
}
#endif

#if CONFIG_BOOT_FROM_JTAG
extern u8 __rom_bss_start__[];
extern u8 __rom_bss_end__[];

static 
HAL_RAM_TEXT_SECTION
VOID
StartupBFJHalInitPlatformLogUart(
    VOID
)
{
    IRQ_HANDLE          UartIrqHandle;
    LOG_UART_ADAPTER    UartAdapter;
    
    //4 Release log uart reset and clock
    LOC_UART_FCTRL(OFF);
    LOC_UART_FCTRL(ON);
    ACTCK_LOG_UART_CCTRL(ON);
    //PinCtrl(LOG_UART,S0,ON);

    //4 Register Log Uart Callback function
    UartIrqHandle.Data = (u32)NULL;//(u32)&UartAdapter;
    UartIrqHandle.IrqNum = UART_LOG_IRQ;
    UartIrqHandle.IrqFun = (IRQ_FUN) UartLogIrqHandle;
    UartIrqHandle.Priority = 0;

    //4 Inital Log uart
    UartAdapter.BaudRate = UART_BAUD_RATE_38400;
    UartAdapter.DataLength = UART_DATA_LEN_8BIT;
    UartAdapter.FIFOControl = 0xC1;
    UartAdapter.IntEnReg = 0x0;///0x00;
    UartAdapter.Parity = UART_PARITY_DISABLE;
    UartAdapter.Stop = UART_STOP_1BIT;

    //4 Initial Log Uart
    StartupHalLogUartInit(UartAdapter);
    
    //4 Register Isr handle
    InterruptRegister(&UartIrqHandle); 
    
    UartAdapter.IntEnReg = 0x05;

    //4 Initial Log Uart for Interrupt
    StartupHalLogUartInit(UartAdapter);
}


 
#ifdef CONFIG_TIMER_MODULE
static 
HAL_RAM_TEXT_SECTION
VOID
StartupBFJHalInitPlatformTimer(
VOID
)
{
    TIMER_ADAPTER       TimerAdapter;

    HAL_WRITE32(SYSTEM_CTRL_BASE, 0x204, 0x3);

    OSC32K_CKGEN_CTRL(ON);
    GTIMER_FCTRL(ON);
    ACTCK_TIMER_CCTRL(ON);
    SLPCK_TIMER_CCTRL(ON);
    TimerAdapter.IrqDis = ON;
//    TimerAdapter.IrqHandle = (IRQ_FUN)NULL;
    TimerAdapter.TimerId = 1;
    TimerAdapter.TimerIrqPriority = 0;
    TimerAdapter.TimerLoadValueUs = 0;
    TimerAdapter.TimerMode = FREE_RUN_MODE;

    HalTimerOpInit((VOID*)(&HalTimerOp));
    HalTimerOp.HalTimerInit((VOID*) &TimerAdapter);
}
#endif



HAL_RAM_TEXT_SECTION
void RtlBootToSram(
    VOID
)
{
#if defined ( __ICCARM__ )   
    __iar_data_init3();
#endif 
    PRAM_START_FUNCTION Image2EntryFun=(PRAM_START_FUNCTION)__image2_entry_func__;
    
    {
        //3 Rom Bss Iitial
        u32 BssLen = (__rom_bss_end__ - __rom_bss_start__);

		// for initial spic flash
        u32 SpicBitMode;
        u32 PinLocat;
        _memset((void *) __rom_bss_start__, 0, BssLen);
        
        ACTCK_VENDOR_CCTRL(ON);
        SLPCK_VENDOR_CCTRL(ON);
        PinCtrl(JTAG, S0, ON);
        HAL_WRITE32(0x40000000, 0x320, 0x7FF);
        SPI_FLASH_PIN_FCTRL(ON);
        JTAG_PIN_FCTRL(ON);
        LOG_UART_PIN_FCTRL(ON);

        //2 Need Modify
        VectorTableInitRtl8195A(0x1FFFFFFC);

        //3 Enable devide 0 and non-alignment access
//        NVIC_SetCCR();
        //for initial spic flash
        FLASH_FCTRL(ON);
        ACTCK_FLASH_CCTRL(ON);
        SLPCK_FLASH_CCTRL(ON);
        PinCtrl(SPI_FLASH, PinLocat, ON);

        //3 Change CPU Clk
        HAL_WRITE8(SYSTEM_CTRL_BASE, 0x14, 
                (HAL_READ8(SYSTEM_CTRL_BASE,0x14)&(~0x70))|CPU_CLOCK_SEL_VALUE);

        //3 Initial Log Uart    
        StartupHalInitialROMCodeGlobalVar();
        StartupBFJHalInitPlatformLogUart();
    
        //3 Initial hardware timer
#ifdef CONFIG_TIMER_MODULE
        StartupBFJHalInitPlatformTimer();
#endif


#ifdef CONFIG_SPIC_MODULE  
	// Config spic dual mode
#ifdef CONFIG_MP
        SpicBitMode = SpicOneBitMode;
#else
        SpicBitMode = SpicDualBitMode;
#endif  //CONFIG_MP
		SpicInitRtl8195A(1,SpicBitMode);
        SpicFlashInit(SpicBitMode);
#endif  //CONFIG_SPIC_MODULE


        DBG_8195A("===== Enter Image 1.5 ====\n");

    }

    InfraStart();
}
#endif

/**
  * @brief  SYSCpuClkConfig. To config cpu clock by using the new value.
  *            Updating SystemCoreClock, flash timing calibration and Log Uart 
  *            initialization are also being done.
  *
  * @param  IN  u8  SysCpuClk: the new CPU clock in _EFUSE_CPU_CLK_ format.
  *
  * @retval None
  */
HAL_RAM_TEXT_SECTION
VOID
SYSCpuClkConfig(
    IN  u8  SysCpuClk
)
{
    DBG_SPIF_INFO("%s(0x%x)\n", __func__, SysCpuClk);

    /* Change to the new CPU clock */ 
#if CONFIG_CHIP_A_CUT
	HAL_WRITE8(SYSTEM_CTRL_BASE, 0x14, 
                (HAL_READ8(SYSTEM_CTRL_BASE,0x14)&(~0x70))|CPU_CLOCK_SEL_VALUE);
#else   
    HalCpuClkConfig(SysCpuClk);
#endif
    /* Update value of SystemCoreClock */
    //SystemCoreClockUpdate();
    #ifdef CONFIG_TIMER_MODULE
        HalDelayUs(1000);
    #endif

    /* Initialize Log Uart again */
    StartupHalInitPlatformLogUart();

#ifdef CONFIG_SPIC_MODULE 
    /* Flash calibration for one-bit mode */
    SpicOneBitCalibrationRtl8195A(SysCpuClk);
#endif

    
}


//3 Image 1
HAL_RAM_TEXT_SECTION
VOID
PreProcessForVendor(
    VOID
)
{
#if defined ( __ICCARM__ )   
    __iar_data_init3();
#endif 
	
    u32 Image2Len, Image2Addr, ImageIndex, SpicBitMode, SpicImageIndex;
    u32 Image2LoadAddr;
    PRAM_START_FUNCTION Image2EntryFun=(PRAM_START_FUNCTION)__image2_entry_func__;
    u32 BssLen = (__image1_bss_end__ - __image1_bss_start__);

    _memset((void *) __image1_bss_start__, 0, BssLen);

    SpicImageIndex = 0;

    PinCtrl(JTAG, S0, ON);

    #if CONFIG_CHIP_A_CUT
    ACTCK_VENDOR_CCTRL(ON);
    SLPCK_VENDOR_CCTRL(ON);
    //PinCtrl(JTAG, S0, ON);
    HAL_WRITE32(0x40000000, 0x320, 0x7FF);
	SPI_FLASH_PIN_FCTRL(ON);
	JTAG_PIN_FCTRL(ON);
	LOG_UART_PIN_FCTRL(ON);

    #ifdef CONFIG_TIMER_MODULE
    StartupHalInitPlatformTimer();
    HalDelayUs(1000);
    #endif
    #elif CONFIG_CHIP_B_CUT
    
    #ifdef CONFIG_TIMER_MODULE
    HalDelayUs(1000);
    #endif
    #endif
    
    //3 Change CPU Clk
    /* Jason Deng Modification 20141205 */
#if 1
    SYSCpuClkConfig((u8)(CPU_CLOCK_SEL_VALUE>>4));
#else
    HAL_WRITE8(SYSTEM_CTRL_BASE, 0x14, 
                (HAL_READ8(SYSTEM_CTRL_BASE,0x14)&(~0x70))|CPU_CLOCK_SEL_VALUE);
#endif

    StartupHalInitialROMCodeGlobalVar();
//    ConfigDebugErr = 0;

    StartupHalInitPlatformLogUart();

    DBG_8195A("===== Enter Image 1 ====\n");
   
#ifdef CONFIG_BOOT_PROCEDURE    

    //3 1) Spi flash calibration
#ifdef CONFIG_SPIC_MODULE  
    // Config spic dual mode
#ifdef CONFIG_MP
    SpicBitMode = SpicOneBitMode;
#else
    SpicBitMode = SpicDualBitMode;
#endif  //CONFIG_MP
    SpicFlashInit(SpicBitMode);
#endif  //CONFIG_SPIC_MODULE

#ifdef CONFIG_SDR_EN
#if defined ( __ICCARM__ )  
// SDRAM init from IAR Macro
// FIXME: The 2nd init will block in hal_sdr_controller.c Line 591 wait REG_SDR_CCR
if ((HAL_READ32(PERI_ON_BASE, REG_SOC_FUNC_EN) & BIT(21))==0)
#endif
	SdrControllerInit();
#endif
	
    //3 2) Download image 2    
    Image2LoadAddr = (HAL_READ32(SPI_FLASH_BASE, 0x18)&0xFFFF) * 1024;
    if (Image2LoadAddr == 0) {
        // Old image format
        Image2LoadAddr = HAL_READ32(SPI_FLASH_BASE, 0x10)+0x20;
    }
    DBG_8195A("Image2 @ 0x%08x\n", Image2LoadAddr);

    Image2Len = HAL_READ32(SPI_FLASH_BASE, Image2LoadAddr);
    Image2Addr = HAL_READ32(SPI_FLASH_BASE, (Image2LoadAddr+0x4));
    DBG_8195A("Image2 length: %d, Image Addr: 0x%08x\n",Image2Len, Image2Addr);

    //RtlConsolRom(1000);//each delay is 100us

    for (ImageIndex = 0x10 + Image2LoadAddr; ImageIndex < (Image2Len + Image2LoadAddr + 0x10); ImageIndex = ImageIndex + 4) {
        HAL_WRITE32(Image2Addr, SpicImageIndex,
                    HAL_READ32(SPI_FLASH_BASE, ImageIndex));

        SpicImageIndex += 4;
    }
#ifdef CONFIG_SDR_EN
    u32 Image3LoadAddr;
    u32 Image3Len;
    u32 Image3Addr;

    Image3LoadAddr = Image2LoadAddr + Image2Len+0x10;
    Image3Len = HAL_READ32(SPI_FLASH_BASE, Image3LoadAddr);
    Image3Addr = HAL_READ32(SPI_FLASH_BASE, Image3LoadAddr + 0x4);

	if( (Image3Len==0xFFFFFFFF) || (Image3Len==0) || (Image3Addr!=0x30000000)){
		DBG_8195A("No Image3\n\r");
	}else{
		DBG_8195A("Image3 length: 0x%x, Image3 Addr: 0x%x\n",Image3Len, Image3Addr);
		SpicImageIndex = 0;

		for (ImageIndex = 0x10 + Image3LoadAddr; 
				ImageIndex < (Image3Len + Image3LoadAddr + 0x10);
				ImageIndex = ImageIndex + 4) {
			HAL_WRITE32(Image3Addr, SpicImageIndex,
						HAL_READ32(SPI_FLASH_BASE, ImageIndex));

			SpicImageIndex += 4;
		}
	}
#endif	
#endif

    //3 3) Jump to image 2
//    InfraStart();
    DBG_8195A("Img2 Sign: %s, InfaStart @ 0x%08x\n",__image2_validate_code__, (u32)(Image2EntryFun->RamStartFun));
    if (_strcmp(__image2_validate_code__, "RTKWin")) {
        DBG_8195A("Invalid Image2 Signature\n");
        RtlConsolRom(1000);//each delay is 100us
    }

    Image2EntryFun->RamStartFun();
}


#if defined(CONFIG_WIFI_NORMAL) && defined(CONFIG_NETWORK)
extern VOID wlan_network(VOID);
#endif

#if 0
static 
VOID
HalShowRamBuildInfo(VOID)
{
    
    DBG_8195A("=========================================================\n\n");
    //DBG_8195A("Build Time: "UTS_VERSION"\n");
    DBG_8195A("Build Time: "RTL8195AFW_COMPILE_TIME"\n");
    DBG_8195A("Build Author: "RTL8195AFW_COMPILE_BY"\n");    
    DBG_8195A("Build Host: "RTL8195AFW_COMPILE_HOST"\n");    
    DBG_8195A("Build ToolChain Version: "RTL195AFW_COMPILER"\n\n");    
    DBG_8195A("=========================================================\n");

}
#endif

VOID
SYSPlatformInit(
    VOID
)
{
#ifdef CONFIG_CHIP_A_CUT
    //Set SPS lower voltage
    HAL_WRITE32(SYSTEM_CTRL_BASE, REG_SYS_EFUSE_SYSCFG0, (HAL_READ32(SYSTEM_CTRL_BASE, REG_SYS_EFUSE_SYSCFG0)&0xf0ffffff));
#elif CONFIG_CHIP_B_CUT
    //Set SPS lower voltage
    HAL_WRITE32(SYSTEM_CTRL_BASE, REG_SYS_EFUSE_SYSCFG0, ((HAL_READ32(SYSTEM_CTRL_BASE, REG_SYS_EFUSE_SYSCFG0)&0xf0ffffff)|0x6000000));
#endif
    //ZCD function off
    HAL_WRITE32(SYSTEM_CTRL_BASE, REG_SYS_SWR_CTRL1, (HAL_READ32(SYSTEM_CTRL_BASE, REG_SYS_SWR_CTRL1)&0xfffff0ff));
    //xtal buffer driving current
    HAL_WRITE32(SYSTEM_CTRL_BASE, REG_SYS_XTAL_CTRL1, 
    (HAL_READ32(SYSTEM_CTRL_BASE, REG_SYS_XTAL_CTRL1)&(~(BIT_MASK_SYS_XTAL_DRV_RF1<<BIT_SHIFT_SYS_XTAL_DRV_RF1))|BIT_SYS_XTAL_DRV_RF1(1)));
}

//3 Imgae 2
VOID
INFRA_START_SECTION
InfraStart(VOID)
{   
#ifdef CONFIG_FPGA
    HAL_WRITE32(0xE000ED00, 0x98, 0);
    HAL_WRITE32(0xE000ED00, 0x9C, 0);
    HAL_WRITE32(0xE000ED00, 0xA0, 0x6000027);
    HAL_WRITE32(0xE000ED00, 0x94, 7);
#endif

    DBG_8195A("===== Enter Image 2 ====\n");
    ShowRamBuildInfo();

    //3 0) Vendor Config function
    //4 Ram Bss Iitial
    u32 BssLen = (__bss_end__ - __bss_start__);

    _memset((void *) __bss_start__, 0, BssLen);

    SystemCoreClockUpdate();

    //3 1) Initial Prestart function 
    SYSPlatformInit();

#ifdef CONFIG_RTL_SIM
    while((HAL_READ32(PERI_ON_BASE, REG_SOC_FUNC_EN) & BIT(30)) == 0){

        HAL_WRITE32(SYSTEM_CTRL_BASE, REG_SYS_DSTBY_INFO3, (HAL_READ32(SYSTEM_CTRL_BASE, REG_SYS_DSTBY_INFO3)+1));
    };
#endif

#ifndef CONFIG_FPGA
#ifdef CONFIG_TIMER_MODULE
    Calibration32k();
    
#ifdef CONFIG_WDG
    //WDGInit();
#endif  //CONFIG_WDG
#endif  //CONFIG_TIMER_MODULE
#endif  //CONFIG_FPGA

#if CONFIG_SOC_PS_MODULE
    InitSYSIRQ();
#endif
    
    //3 2) Enter App start function 
//NeoJou
#if 0
#ifdef CONFIG_KERNEL
#ifdef PLATFORM_FREERTOS
    InterruptForOSInit((VOID*)vPortSVCHandler,
                       (VOID*)xPortPendSVHandler,
                       (VOID*)xPortSysTickHandler);
#endif
#endif
#endif
    SpicDisableRtl8195A();  // turn off SPIC for power saving

    _AppStart();

}

