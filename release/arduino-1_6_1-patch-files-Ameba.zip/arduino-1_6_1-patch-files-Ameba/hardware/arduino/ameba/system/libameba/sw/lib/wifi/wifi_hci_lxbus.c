/******************************************************************************
 *
 * Copyright(c) 2007 - 2012 Realtek Corporation. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110, USA
 *
 *
 ******************************************************************************/

#include "basic_types.h"
#include "hal_api.h"
#include "hal_platform.h"
#include "hal_peri_on.h"
#include "rtl8195a_peri_on.h"

#include "wifi_hci_lxbus.h"

#if 1 

void wifi_hci_lxbus_init(void)
{

    //3 Enable Lexra bus
    ACTCK_WL_CCTRL(ON);
    SLPCK_WL_CCTRL(ON);

    //3 Enable lexra bus
    LXBUS_FCTRL(ON);
    //Enable Wlan Mac Top
    WL_MACON_FCTRL(ON);

}

#define IRQ_HANDLED 1
#define IRQ_NONE 0

u32 wifi_hci_dma_Interrupt (
    void* data
)
{
#if 1
	return IRQ_HANDLED;

#else
	struct dvobj_priv *dvobj = (struct dvobj_priv *)data;
	_adapter *adapter = (_adapter *)dvobj->if1;

	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;

	BOOLEAN	wlan_int_asserted;

#if defined(CONFIG_DEBUG_DYNAMIC)
	{
		// for debug usage
		HAL_DATA_TYPE	*pHalData = GET_HAL_DATA(adapter);
		pHalData->debug_info.int_count++;
	}
#endif

	if (dvobj->irq_enabled == 0) {
		return IRQ_HANDLED;
	}

	// Clear interrupt here
	wlan_int_asserted = InterruptRecognized8195a(adapter);
	
#if !defined(INT_HANDLE_IN_ISR)	
	if(!pExportWlanIrqSemaphore)
	{
		printf("%s(%d)\n", __FUNCTION__, __LINE__);
		return IRQ_HANDLED;
	}

	if (wlan_int_asserted == _FALSE) {
		goto done;
	}	
	xSemaphoreGiveFromISR( *pExportWlanIrqSemaphore, &xHigherPriorityTaskWoken );
	/* Switch tasks if necessary. */	
	if( xHigherPriorityTaskWoken != pdFALSE )
	{
		//printf("%s(%d)\n", __FUNCTION__, __LINE__);
		portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
	}

#else

	if (wlan_int_asserted == _FALSE) {
		goto done;
	}

	if(rtw_hal_interrupt_handler(adapter) == _FAIL)
		return IRQ_HANDLED;
#endif		

done:
	return IRQ_HANDLED;
#endif
    
}


//NeoJou
// TODO:
#if 0
s32	InterruptHandle8195a(_adapter *padapter)
{
	_irqL	irqL = 0;
	HAL_DATA_TYPE	*pHalData = GET_HAL_DATA(padapter);
	struct dvobj_priv	*pdvobjpriv = adapter_to_dvobj(padapter);
#ifdef CONFIG_INTERRUPT_BASED_TXBCN
    struct mlme_priv    *pmlmepriv = &padapter->mlmepriv;
#endif
	int	ret = _SUCCESS;

#if !defined(INT_HANDLE_IN_ISR)
	//_enter_critical(&pdvobjpriv->irq_th_lock, &irqL);	
	rtw_enter_critical(&pdvobjpriv->irq_th_lock, &irqL);	
#endif

	//<1> beacon related
	if (pHalData->IntArray[0] & (IMR_TXBCN0ERR_8195A|IMR_TXBCN0OK_8195A)) {
		PADAPTER bcn_adapter = padapter;
#ifdef CONFIG_CONCURRENT_MODE
		if  ((padapter->pbuddy_adapter)&&check_fwstate(&padapter->pbuddy_adapter->mlmepriv, WIFI_AP_STATE))
			bcn_adapter = padapter->pbuddy_adapter;
#endif
		if (bcn_adapter->xmitpriv.beaconDMAing) {
			bcn_adapter->xmitpriv.beaconDMAing = _FAIL;
			rtl8195a_tx_isr(bcn_adapter, BCN_QUEUE_INX);
		}
#ifdef CONFIG_INTERRUPT_BASED_TXBCN

	        if(check_fwstate(pmlmepriv, WIFI_AP_STATE))
	        {
	            if(pmlmepriv->update_bcn == _TRUE)
	            {
	                set_tx_beacon_cmd(padapter);
	            }
	        }
#ifdef CONFIG_CONCURRENT_MODE
        if(check_buddy_fwstate(padapter, WIFI_AP_STATE))
        {
            if(padapter->pbuddy_adapter->mlmepriv.update_bcn == _TRUE)
            {
                set_tx_beacon_cmd(padapter->pbuddy_adapter);
            }
        }
#endif
#endif         
	}
#if defined(CONFIG_AP_MODE)
	/*when ap mode, we should better handle MGT&HO&VO immediately, otherwise skb will
	be exhausted soon especially conconrrent mode enable*/	
	if (pHalData->IntArray[1] & IMR_MGNTDOK_8195A) {
		//DBG_8192C("Manage ok interrupt!\n");	
		rtl8195a_tx_isr(padapter, MGT_QUEUE_INX);
	}

	if (pHalData->IntArray[1] & IMR_H0DOK_8195A) {
		rtl8195a_tx_isr(padapter, HIGH_QUEUE_INX);
	}
	if (pHalData->IntArray[1] & IMR_VODOK_8195A) {
		//DBG_8192C("Vo TX OK interrupt!\n");
		rtl8195a_tx_isr(padapter, VO_QUEUE_INX);
	}
#endif
	if (pHalData->IntArray[1] & IMR_BCNDERR0_8195A) {
        DBG_8192C("Beacon DMA Error!!!\n");
	}

	if (pHalData->IntArray[0] & IMR_BCNDMA0_MSK_8195A) {        
//        DBG_8192C("%s:%d: Bcn early isr\n", __FUNCTION__, __LINE__);
#ifdef PLATFORM_LINUX
		struct tasklet_struct  *bcn_tasklet;
#ifdef CONFIG_CONCURRENT_MODE
		if (padapter->iface_type == IFACE_PORT1)
			bcn_tasklet = &padapter->pbuddy_adapter->recvpriv.irq_prepare_beacon_tasklet;
		else
#endif
			bcn_tasklet = &padapter->recvpriv.irq_prepare_beacon_tasklet;
		tasklet_hi_schedule(bcn_tasklet);
#endif        
#if 0
#ifdef CONFIG_INTERRUPT_BASED_TXBCN

        if(check_fwstate(pmlmepriv, WIFI_AP_STATE))
        {
            if(pmlmepriv->update_bcn == _TRUE)
            {
                set_tx_beacon_cmd(padapter);
            }
        }
#endif
#endif
	}

    //<2> Rx related
    if ((pHalData->IntArray[1] & (IMR_ROK_8195A|IMR_RDU_8195A)) || (pHalData->IntArray[0] & IMR_FOVW_MSK_8195A)) {
        pHalData->IntrMask[1] &= (~(IMR_ROK_8195A|IMR_RDU_8195A));
        pHalData->IntrMask[0] &= (~IMR_FOVW_MSK_8195A);        
        rtw_write32(padapter, REG_LX_DMA_IMR, pHalData->IntrMask[1]);
        rtw_write32(padapter, REG_FWIMR, pHalData->IntrMask[0]);

    	if ((pHalData->IntArray[1] & (IMR_RDU_8195A)) || (pHalData->IntArray[0] & IMR_FOVW_MSK_8195A)) 
    		DBG_8192C("%s(%d), IMR_RDU_8195 = %d,  IMR_RXFOVW_8195 = %d\n", (pHalData->IntArray[1] & (IMR_RDU_8195A)), (pHalData->IntArray[0] & IMR_FOVW_MSK_8195A));
#ifdef CONFIG_WLAN_HAL_TEST
		//DBG_8192C("Recevice RX Data\n");
#ifdef CONFIG_WLAN_HAL_RX_TASK
        RtlUpSemaFromISR((_sema *)&WlanRxSema);
#else
        rtl8195a_recv_tasklet(padapter);
#endif
#else
#ifdef CONFIG_RECV_TASKLET_THREAD
        //DBG_8192C("Recevice RX Data\n");
        rtw_up_sema(&padapter->recvtasklet_thread.wakeup_sema);     		
#else
        rtl8195a_recv_tasklet(padapter);
#endif
#endif
    }
#ifdef TX_CHECK_DSEC_ALWAYS
	//<3> Tx related
	rtl8195a_tx_int_handler(padapter);
#else	
	if (pHalData->IntArray[0] & IMR_TXFOVW_MSK_8195A) {
		DBG_8192C("IMR_TXFOVW!\n");
	}

	/*if (pHalData->IntArray[0] & IMR_TX_MASK) {
		pHalData->IntrMask[0] &= (~(IMR_TX_MASK));
		rtw_write32(padapter, REG_HIMR0_8812, pHalData->IntrMask[0]);
		tasklet_hi_schedule(&pxmitpriv->xmit_tasklet);
	}*/

	if (pHalData->IntArray[1] & IMR_MGNTDOK_8195A) {
		//DBG_8192C("Manage ok interrupt!\n");		
		rtl8195a_tx_isr(padapter, MGT_QUEUE_INX);
	}
    
	if (pHalData->IntArray[1] & IMR_H0DOK_8195A) {
		//DBG_8192C("HIGH_QUEUE ok interrupt!\n");
		rtl8195a_tx_isr(padapter, HIGH_QUEUE_INX);
	}

	if (pHalData->IntArray[1] & IMR_BKDOK_8195A) {
//		DBG_8192C("BK Tx OK interrupt!\n");
		rtl8195a_tx_isr(padapter, BK_QUEUE_INX);
	}

	if (pHalData->IntArray[1] & IMR_BEDOK_8195A) {
//		DBG_8192C("BE TX OK interrupt!\n");
		rtl8195a_tx_isr(padapter, BE_QUEUE_INX);
	}

	if (pHalData->IntArray[1] & IMR_VIDOK_8195A) {
//		DBG_8192C("VI TX OK interrupt!\n");
		rtl8195a_tx_isr(padapter, VI_QUEUE_INX);
	}

	if (pHalData->IntArray[1] & IMR_VODOK_8195A) {
//		DBG_8192C("Vo TX OK interrupt!\n");
		rtl8195a_tx_isr(padapter, VO_QUEUE_INX);
	}

#endif //TX_CHECK_DSEC_ALWAYS
#ifndef CONFIG_WLAN_HAL_TEST
	#ifdef CONFIG_XMIT_TASKLET_THREAD
		//Trigger xmit tasklet forcely no matther whether there is tx interrupt okay or not
//		rtw_up_sema(&padapter->xmittasklet_thread.wakeup_sema);
	#endif
#endif

#ifdef CONFIG_LITTLE_WIFI_MCU_FUNCTION_THREAD
    {
        if (pHalData->IntArray[0] & IMR_TBTTINT_MSK_8195A) {
		    if (pHalData->PMUTaskRAEn) {
                pHalData->WifiMcuCmdBitMap |= RATEADAPTIVE;
                rtw_up_sema(&pHalData->littlewifipriv.wakeup_sema);
		    }
	    }

        if (pHalData->IntArray[0] & IMR_TRY_DONE_MSK_8195A) {
		    if (pHalData->PMUTaskRAEn) {
                pHalData->WifiMcuCmdBitMap |= RATRYDONE;
                rtw_up_sema(&pHalData->littlewifipriv.wakeup_sema);
		    }
	    }
    }
#endif
#ifdef CONFIG_WLAN_HAL_TEST
done:
#endif


#if !defined(INT_HANDLE_IN_ISR)
	//_exit_critical(&pdvobjpriv->irq_th_lock, &irqL);
	rtw_exit_critical(&pdvobjpriv->irq_th_lock, &irqL);
#endif

//DBG_871X("%s(%d) Exit <==\n", __FUNCTION__, __LINE__);  


	return ret;

}
#endif


#else

#define _LXBUS_HCI_INTF_C_

#include <drv_types.h>

/*8195 platform related include file */
#include <rtl8195a_hal.h>
#include "rtl8195a_peri_on.h"
#include "hal_platform.h"
#include "hal_api.h"
#include "hal_peri_on.h"
#include "hal_irqn.h"
#include <rtl8195a_it.h>
#include <hal_vector_table.h>



void hci_lxbus_intf_stop(PADAPTER padapter)
{

    if ((!is_primary_adapter(padapter)) && padapter->pbuddy_adapter){
        padapter = padapter->pbuddy_adapter;
    }

    //Disable hw interrupt
    if(padapter->bSurpriseRemoved == _FALSE)
    {
        //device still exists, so driver can do i/o operation

        if (padapter->HalFunc.disable_interrupt)
            padapter->HalFunc.disable_interrupt(padapter);

        rtw_hal_irp_reset(padapter);

        RT_TRACE(_module_hci_intfs_c_,_drv_err_,("hci_lxbus_intf_stop: SurpriseRemoved==_FALSE\n"));
    }else
    {
        // there should be no such case for lextra bus
        RT_TRACE(_module_hci_intfs_c_,_drv_err_,("hci_lxbus_intf_stop: SurpriseRemoved==_TRUE\n"));
    }

}

struct dvobj_priv *hci_lxbus_dvobj_init(void)
{
//  int status = _FAIL;
    struct dvobj_priv *dvobj = NULL;

_func_enter_;

    dvobj = (struct dvobj_priv*)rtw_zmalloc(sizeof(*dvobj));
    if (NULL == dvobj) {
        goto exit;
    }

    //3 Enable Lexra bus
    ACTCK_WL_CCTRL(ON);
    SLPCK_WL_CCTRL(ON);

    //3 Enable lexra bus
    LXBUS_FCTRL(ON);
    //Enable Wlan Mac Top
    WL_MACON_FCTRL(ON);

//  status = _SUCCESS;

//free_dvobj:
//  if (status != _SUCCESS && dvobj) {
//      rtw_mfree((u8*)dvobj, sizeof(*dvobj));
//      dvobj = NULL;
//  }

exit:
_func_exit_;

    return dvobj;
}


void hci_lxbus_dvobj_deinit(struct dvobj_priv *dvobj)
{
    if (dvobj)
    {
        rtw_mfree((u8*)dvobj, sizeof(*dvobj));
    }

    //3 Disable Lexra bus
    //Disable Wlan Mac Top
    WL_MACON_FCTRL(OFF);
    //Disable lexra bus
    LXBUS_FCTRL(OFF);

    ACTCK_WL_CCTRL(OFF);
    SLPCK_WL_CCTRL(OFF);
}

void hci_lxbus_dvobj_request_irq(struct dvobj_priv *dvobj)
{

    DBG_8192C("Register Wlan DMA Interrupt\n");
    IRQ_HANDLE      WlanDmaIrqHandle, WlanProtocolIrqHandle;
    WlanDmaIrqHandle.Data = (u32) (dvobj);
    WlanDmaIrqHandle.IrqNum = WL_DMA_IRQ;
    WlanDmaIrqHandle.IrqFun = (IRQ_FUN) lextra_bus_dma_Interrupt;
    WlanDmaIrqHandle.Priority = 14;

    InterruptRegister(&WlanDmaIrqHandle);
    InterruptEn(&WlanDmaIrqHandle);

    DBG_8192C("Register Wlan Protocal Interrupt\n");

    WlanProtocolIrqHandle.Data = (u32) (dvobj);
    WlanProtocolIrqHandle.IrqNum = WL_PROTOCOL_IRQ;
    WlanProtocolIrqHandle.IrqFun = (IRQ_FUN) lextra_bus_dma_Interrupt;
    WlanProtocolIrqHandle.Priority = 15;

    InterruptRegister(&WlanProtocolIrqHandle);
    InterruptEn(&WlanProtocolIrqHandle);

    dvobj->irq_alloc = 1;
    dvobj->irq_enabled= 1;


    // printf debug message
    //printk("\rreg 002: 0x%x\n",rtw_read16(dvobj->if1,REG_SYS_FUNC_EN));
    //printk("\rreg 01F: 0x%x\n",rtw_read8(dvobj->if1,REG_RF_CTRL));
    //printk("\rreg 0b0: 0x%x\n",rtw_read32(dvobj->if1,REG_HIMR));
    //printk("\rreg 0b4: 0x%x\n",rtw_read32(dvobj->if1,REG_HISR));
    //printk("\rreg 11c: %d\n",rtw_read32(dvobj->if1,REG_RXFF_PTR));
}

void hci_lxbus_free_irq(struct dvobj_priv *dvobj)
{

    if (dvobj->irq_alloc) {
        DBG_8192C("De-Register Wlan DMA Interrupt\n");
        IRQ_HANDLE      WlanDmaIrqHandle, WlanProtocolIrqHandle;
        WlanDmaIrqHandle.Data = (u32) (dvobj);
        WlanDmaIrqHandle.IrqNum = WL_DMA_IRQ;
        WlanDmaIrqHandle.IrqFun = (IRQ_FUN) lextra_bus_dma_Interrupt;
        WlanDmaIrqHandle.Priority = 14;

        InterruptDis(&WlanDmaIrqHandle);
        InterruptUnRegister(&WlanDmaIrqHandle);

        DBG_8192C("De-Register Wlan Protocol Interrupt\n");
        WlanProtocolIrqHandle.Data = (u32) (dvobj);
        WlanProtocolIrqHandle.IrqNum = WL_PROTOCOL_IRQ;
        WlanProtocolIrqHandle.IrqFun = (IRQ_FUN) lextra_bus_dma_Interrupt;
        WlanProtocolIrqHandle.Priority = 15;

        InterruptDis(&WlanProtocolIrqHandle);
        InterruptUnRegister(&WlanProtocolIrqHandle);

        dvobj->irq_enabled = 0;
        dvobj->irq_alloc = 0;
    }
}


const struct host_ctrl_intf_ops hci_ops = {
    hci_lxbus_dvobj_init,
    hci_lxbus_dvobj_deinit,
    hci_lxbus_dvobj_request_irq,
    hci_lxbus_free_irq
};


#endif


