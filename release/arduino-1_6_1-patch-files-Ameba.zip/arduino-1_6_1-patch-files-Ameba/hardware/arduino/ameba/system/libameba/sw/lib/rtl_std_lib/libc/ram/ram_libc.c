/******************************************************************************
 *
 * Copyright(c) 2007 - 2014 Realtek Corporation. All rights reserved.
 *                                        
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110, USA
 *
 *
 ******************************************************************************/

#include <_ansi.h>
#include <reent.h>
#include <stdio.h>
#include <stdarg.h>

#include "rtl_lib.h"
#include "rt_lib_rom.h"
#include "section_config.h"


static int libc_has_init = 0;

//struct _reent impure_data = _REENT_INIT (impure_data);
#ifdef CONFIG_LINK_ROM_SYMB

HAL_RAM_DATA_SECTION
static struct _reent impure_data = _REENT_INIT (impure_data);

HAL_RAM_DATA_SECTION
struct _reent * _rtl_impure_ptr = &impure_data;

#else
extern struct _reent *_rtl_impure_ptr __ATTRIBUTE_IMPURE_PTR__;
#endif

void rtl_libc_init(void) {

	//_impure_ptr = &(impure_data);
	
	__rom_mallocr_init();

	init_rom_libgloss_ram_map();

}

int rtl_printf(const char* fmt, ...)
{
	int ret;
	va_list ap;
	struct _reent *ptr = _rtl_impure_ptr;


	if ( !libc_has_init ) {
		rtl_libc_init();
		libc_has_init = 1; 
	}

	_REENT_SMALL_CHECK_INIT (ptr);
	va_start (ap, fmt);
	ret = __rtl_vfprintf_r (ptr, _stdout_r (ptr), fmt, ap);
	va_end (ap);
	return ret;

}

int rtl_vfprintf(FILE *fp, const char *fmt0, va_list ap) 
{
  int result;

  if ( !libc_has_init ) {
	  rtl_libc_init();
	  libc_has_init = 1; 
  }

  result = __rtl_vfprintf_r (_REENT, fp, fmt0, ap);
  return result;
}



void * rtl_memset(void * m , int c , size_t n)
{
	return __rtl_memset(m, c, n);
}

void * rtl_memchr(const void * src_void , int c , size_t length)
{
	return __rtl_memchr(src_void, c, length);
}

void * rtl_memmove( void * dst_void , const void * src_void , size_t length)
{
	return __rtl_memmove(dst_void, src_void, length);
}

int rtl_strcmp(const char *s1 ,	const char *s2)
{
	return __rtl_strcmp(s1, s2);
}


