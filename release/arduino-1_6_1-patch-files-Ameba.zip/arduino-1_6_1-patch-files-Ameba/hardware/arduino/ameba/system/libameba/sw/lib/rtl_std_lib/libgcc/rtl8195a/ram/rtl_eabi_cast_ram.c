/******************************************************************************
 *
 * Copyright(c) 2007 - 2014 Realtek Corporation. All rights reserved.
 *                                        
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110, USA
 *
 *
 ******************************************************************************/

#include <rtl_math_types.h>
#include <rtl_math_diag.h>

#include <rtl_eabi_cast_ram.h>
#include <rtl_eabi_cast_rom.h>

#include <rtl_lib.h>


int rtl_dtoi(double d)
{
	return __rtl_dtoi(d);
}


unsigned int rtl_dtoui(double d)
{
	return __rtl_dtoui(d);
}


float rtl_i2f(int val)
{
	return __rtl_itof(val);
	
}

double rtl_i2d(int val)
{
	return __rtl_itod(val);
}

float rtl_ui2f(unsigned int val)
{
	return __rtl_uitof(val);
}

double rtl_ui2d(unsigned int val)
{
	return __rtl_uitod(val);
}


char* rtl_itoa( int value, char *string, int radix )
{
	return rtl_ltoa( value, string, radix ) ;
}

char* rtl_ltoa( long value, char *string, int radix )
{
	return __rtl_ltoa_v1_00(value, string, radix);
}


char* rtl_utoa( unsigned long value, char *string, int radix )
{
	return rtl_ultoa( value, string, radix ) ;
}

char* rtl_ultoa( unsigned long value, char *string, int radix )
{
	return __rtl_ultoa_v1_00(value, string, radix);
}

#if 0
//change to use stdio::printf
char* rtl_ftoa(char *a, float f, int digits)
{
	return rtl_dtoa(a, (double)f, digits);
}


char* rtl_dtoa(char *a, double d, int digits)
{
	return __rtl_dtoa_v1_00(a, d, digits);
}
#endif


long rtl_ftol(float f)
{
	return __rtl_ftol(f);
}

double rtl_ftod(float f)
{
	return __rtl_ftod(f);
}

float rtl_dtof(double d)
{
	return __rtl_dtof(d);
}


float rtl_fadd(float a, float b)
{
	return __rtl_fadd(a, b);
}

float rtl_fsub(float a, float b)
{
	return __rtl_fsub(a, b);
}

float rtl_fmul(float a, float b)
{
	return __rtl_fmul(a, b);
}

float rtl_fdiv(float a, float b)
{
	return __rtl_fdiv(a, b);
}

#if 0
float rtl_fsqrt(float a)
{
	return __rtl_fsqrt(a);
}
#endif


double rtl_dadd(double a, double b)
{
	return __rtl_dadd(a, b);
}

double rtl_dsub(double a, double b)
{
	return __rtl_dsub(a, b);
}

double rtl_dmul(double a, double b)
{
	return __rtl_dmul(a, b);
}

double rtl_ddiv(double a, double b)
{
	return __rtl_ddiv(a, b);
}

int rtl_dcmpeq(double a, double b)
{
	return __rtl_dcmpeq(a, b);
}

int rtl_dcmplt(double a, double b)
{
	return __rtl_dcmplt(a, b);
}

int rtl_dcmple(double a, double b)
{
	return __rtl_dcmple(a, b);
}

int rtl_dcmpgt(double a, double b)
{
	return __rtl_dcmpgt(a, b);
}

int rtl_fcmplt(float a, float b)
{
	return __rtl_fcmplt(a, b);
}

int rtl_fcmpgt(float a, float b)
{
	return __rtl_fcmpgt(a, b);
}


//
// __aeabi_
//

#if 0

float __aeabi_i2f(int val)
{
	return rtl_i2f(val);
}



double __aeabi_i2d(int val)
{
	return rtl_i2d(val);
}



float __aeabi_ui2f(unsigned int val)
{
	return rtl_ui2f(val);
}


double __aeabi_ui2d(unsigned int val)
{
	return rtl_ui2d(val);
}


int __aeabi_d2iz(double d)
{
	return rtl_dtoi(d);
}



unsigned int __aeabi_f2uiz(float d)
{
	return rtl_dtoui(d);
}


unsigned int __aeabi_d2uiz(double d)
{
	return rtl_dtoui(d);
}


int __aeabi_f2iz(float f)
{
	return rtl_ftol(f);
}

double __aeabi_f2d(float f)
{
	return rtl_ftod(f);
}


float __aeabi_d2f(double d)
{
	return rtl_dtof(d);
}

float __aeabi_fadd(float a, float b)
{
	return rtl_fadd(a, b);
}

float __aeabi_fsub(float a, float b)
{
	return rtl_fsub(a, b);
}

float __aeabi_fmul(float a, float b)
{
	return rtl_fmul(a, b);
}

float __aeabi_fdiv(float a, float b)
{
	return rtl_fdiv(a, b);
}


double __aeabi_dadd(double a, double b)
{
	return rtl_dadd(a, b);
}


double __aeabi_dsub(double a, double b)
{
	return rtl_dsub(a, b);
}


double __aeabi_dmul(double a, double b)
{
	return rtl_dmul(a, b);
}



double __aeabi_ddiv(double a, double b)
{
	return rtl_ddiv(a, b);
}


int __aeabi_dcmpeq(double a, double b)
{
	return rtl_dcmpeq(a, b);
}



int __aeabi_dcmplt(double a, double b)
{
	return rtl_dcmplt(a, b);
}



int __aeabi_fcmplt(float a, float b)
{
	return rtl_fcmplt(a, b);
}


int __aeabi_dcmple(double a, double b)
{
	return rtl_dcmple(a, b);
}


int __aeabi_dcmpgt(double a, double b)
{
	return rtl_dcmpgt(a, b);
}


int __aeabi_fcmpgt(float a, float b)
{
	return rtl_fcmpgt(a, b);
}

int __aeabi_dcmpge(double a, double b)
{
	return !rtl_dcmplt(a, b);
}

#endif

