/******************************************************************************
 *
 * Copyright(c) 2007 - 2011 Realtek Corporation. All rights reserved.
 *                                        
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110, USA
 *
 *
 ******************************************************************************/
#ifndef __WIFI_ODM_H__
#define __WIFI_ODM_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "basic_types.h"


//  SupportPlatform
#define	ODM_AP		 	0x01	//BIT0 
#define	ODM_ADSL	 	0x02	//BIT1
#define	ODM_CE		 	0x04	//BIT2
#define	ODM_WIN		 	0x08	//BIT3

// SupportInterface
enum HCI_INTERFACE_TYPE {
	RTW_PCIE	= BIT0,
	RTW_USB 	= BIT1,
	RTW_SDIO	= BIT2,
	RTW_GSPI	= BIT3,
	RTW_LXBUS	= BIT4,
};


typedef  struct DM_Out_Source_Dynamic_Mechanism_Structure
{
	
	// ODM Platform info AP/ADSL/CE/MP = 1/2/3/4
	uint8_t		SupportPlatform;

	
	// ODM PCIE/USB/SDIO = 1/2/3
	uint8_t			SupportInterface;			
 
} DM_ODM_T, *PDM_ODM_T;		// DM_Dynamic_Mechanism_Structure




#ifdef __cplusplus
}
#endif


#endif //__HAL_PHY_H__
