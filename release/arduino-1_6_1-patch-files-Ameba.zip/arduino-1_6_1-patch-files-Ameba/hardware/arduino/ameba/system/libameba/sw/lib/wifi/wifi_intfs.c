/******************************************************************************
 *
 * Copyright(c) 2007 - 2011 Realtek Corporation. All rights reserved.
 *                                        
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110, USA
 *
 *
 ******************************************************************************/

#include "basic_types.h"
#include "wifi_hci_lxbus.h"
#include "rtl8195a_sys_on.h"

#include "wifi_intfs.h"
#include "wifi_reg.h"

#include "hal_efuse.h"
#include "HalPwrSeqCmd.h"

#include "HalHWImg8195A.h"
#include "wifi_odm.h"

#if 1

static void _InitRFType(void)
{
	//pHalData->rf_chip	= RF_6052;
	//pHalData->rf_type = RF_1T1R;
}

static void PHY_MACConfig8195A(void)
{
	ODM_ReadAndConfig_MP_8195A_MAC_REG();
}

static int PHY_BBConfig8195A(RTW_WIFI_HAL_DATA *pHalData)
{
	int	rtStatus = _SUCCESS;
	//HAL_DATA_TYPE	*pHalData = GET_HAL_DATA(Adapter);
	u32	RegVal;


	// TODO: 
	//phy_InitBBRFRegisterDefinition(Adapter);

	// Enable BB and RF
	RegVal = HAL_WL_READ32(REG_WL_FUNC_EN);
	HAL_WL_WRITE32(REG_WL_FUNC_EN, (u32)(RegVal|BIT16|BIT17));

	HAL_WL_WRITE8(REG_WL_FUNC_EN+3, RF_EN|RF_RSTB|RF_SDMRSTB);

    //Diable RF and AFE clcok gate in XTAL 
	HAL_WL_WRITE8(REG_WL_AFE_CTRL, 0);

	//
	// Config BB and AGC
	//
	// rtStatus = phy_BB8195a_Config_ParaFile(Adapter);
	ODM_ReadAndConfig_MP_8195A_PHY_REG();
	

	// all zero
	// PHY_InitTxPowerByRate( Adapter );

	ODM_ReadAndConfig_MP_8195A_AGC_TAB(&(pHalData->odmpriv));
	

	return rtStatus;
	
	
}


#define 	RF_Reg_intfs				0x870
#define 	RF_Reg_intfe				0x860
#define 	RF_Reg_intfo				0x860
#define 	RF_Reg_HSSIPara2			0x824

#define		bRFSI_RFENV               	(uint32_t)(0x10)	
#define		b3WireAddressLength       	0x400
#define		b3WireDataLength          	0x800



#if 1

static inline u32 wifiReg_calBitShift(u32 bitmask)
{
    return (bitmask&0x1)? 0 : (1+wifiReg_calBitShift(bitmask>>1));
}

#else
static inline u32 wifiReg_calBitShift(u32 bitmask)
{
	u32 i;

	for(i=0; i<32; i++)
	{
		if ( ((bitmask>>i) &  0x1 ) == 1)
			break;
	}

	return (i);
}
#endif


static inline u32 wifiReg_read32(u32 addr, u32 bitmask)
{
	u32 retValue, bitshift;

	retValue = HAL_WL_READ32(addr);
	bitshift = wifiReg_calBitShift(bitmask);
	retValue = (retValue & bitmask) >> bitshift;

	return retValue;
}

static inline void wifiReg_write32(u32 addr, u32 bitmask, u32 data)
{
	u32 orig_value, bitshift;
	
	if(bitmask!= 0xFFFFFFFF){//if not "double word" write
		orig_value =wifiReg_read32;
		bitshift = wifiReg_calBitShift(bitmask);
		data = ((orig_value & (~bitmask)) | ((data << bitshift) & bitmask));
	}

	HAL_WL_WRITE32(addr, data);
}


//static inline u32 PHY_RFConfig8195A(RTW_WIFI_HAL_DATA *pHalData)
static inline uint32_t PHY_RFConfig8195A(void)
{
	//pHalData->NumTotalRFPath = 1;
	//RF_PATH_A

	uint32_t u4RegValue;

#if 0
	
	u4RegValue = wifiReg_read32(RF_Reg_intfs, 0x38);
	return u4RegValue;
#else

	u4RegValue = wifiReg_read32(RF_Reg_intfs, bRFSI_RFENV);

	DiagPrintf("PHY_RFConfig8195A - 0\n");

	/*----Set RF_ENV enable----*/
	wifiReg_write32(RF_Reg_intfe, bRFSI_RFENV<<16, 0x1);
	DiagPrintf("PHY_RFConfig8195A - 0-1\n");

	HalDelayUs(1);

	DiagPrintf("PHY_RFConfig8195A - 1\n");

	/*----Set RF_ENV output high----*/
	wifiReg_write32(RF_Reg_intfo, bRFSI_RFENV, 0x1);
	HalDelayUs(1);

	DiagPrintf("PHY_RFConfig8195A - 2\n");

	/* Set bit number of Address and Data for RF register */
	wifiReg_write32(RF_Reg_HSSIPara2, b3WireAddressLength, 0x0);	
	HalDelayUs(1);

	DiagPrintf("PHY_RFConfig8195A - 3\n");

	wifiReg_write32(RF_Reg_HSSIPara2, b3WireDataLength, 0x0); 
	HalDelayUs(1);

	DiagPrintf("PHY_RFConfig8195A - 4\n");

	//ODM_ReadAndConfig_MP_8195A_RadioA();

	DiagPrintf("PHY_RFConfig8195A - 5\n");


	// restore bRFSI_RFENV
	wifiReg_write32(RF_Reg_intfs, bRFSI_RFENV, u4RegValue);

	DiagPrintf("PHY_RFConfig8195A - finished\n");

	return 0;
#endif
}


void rtw_wifi_init(RTW_WIFI_HAL_DATA *pHalData)
{

#if 1

#if 1 



#else
	wifi_hci_lxbus_init();

    rtw_read_chip_version(pHalData);

	pHalData->bMacPwrCtrlOn = _FALSE;
	rtw_power_on(pHalData);

	rtw_read_efuse(pHalData);

	rtw_hal_dm_init(pHalData);

	rtw_disable_interrupt();

	//rtw_init_drv_sw
	// psta->mac_id = 1;

	// Init_ODM_ComInfo_8195a
	// hci_lxbus_dvobj_request_irq

	// rtl8195a_hal_init
	
	//rtw_write8(padapter, REG_EARLY_MODE_CONTROL, 0);
	HAL_WL_WRITE8(REG_EARLY_MODE_CONTROL, 0);
	//padapter->bFWReady = _TRUE;
	//pHalData->fw_ractrl = _TRUE;
	// pwrctrlpriv->reg_rfoff == _FALSE
    // padapter->HardwareType = HARDWARE_TYPE_RTL8195A;
	
	// Set RF type for BB/RF configuration
	_InitRFType();

	// pHalData->CurrentChannel = 6;
	PHY_MACConfig8195A();

	PHY_BBConfig8195A(pHalData);
	//PHY_RFConfig8195A(pHalData);
	//PHY_RFConfig8195A();
#endif
	
#else
	int status = _FAIL;
	struct net_device *pnetdev;
	PADAPTER padapter = NULL;

	padapter = (PADAPTER)rtw_zvmalloc(sizeof(*padapter));
	if (NULL == padapter) {
		goto exit;
	}

	padapter->dvobj = dvobj;
	dvobj->if1 = (void*)padapter;

	padapter->bDriverStopped = _TRUE;
	
	padapter->hw_init_mutex = &drvpriv.hw_init_mutex;
	padapter->work_mode = mode;

	padapter->interface_type = (u16) hci_bus_intf_type;
	decide_chip_type_by_device_id(padapter);

	//3 1. init network device data
	pnetdev = rtw_init_netdev(padapter);
	if (!pnetdev)
		goto free_adapter;

	SET_NETDEV_DEV(pnetdev, dvobj_to_dev(dvobj));

#ifdef CONFIG_IOCTL_CFG80211
	rtw_wdev_alloc(padapter, dvobj_to_dev(dvobj));
#endif

	//3 2. Initialize I/O operation for different bus interface
	if (rtw_init_io_priv(padapter, hci_set_intf_ops) == _FAIL)
	{
		RT_TRACE(_module_hci_intfs_c_, _drv_err_,
			("%s: Can't init io_priv\n", __FUNCTION__));
		goto free_adapter;
	}

	//3 3. init driver special setting, interface, OS and hardware relative
	if(hal_set_hal_ops(padapter) == _FAIL)
		goto free_hal_data;

	//3 4. The most first initial hardware setting for different bus interface
	rtw_hal_chip_configure(padapter);

	//3 5. initialize Chip version	
	rtw_hal_read_chip_version(padapter);	

	//3 6. read efuse/eeprom data
	rtw_hal_read_chip_info(padapter);

	//3 7. Initialize bus start/stop operation
	padapter->intf_start = &hci_intf_start;
	padapter->intf_stop = &hci_intf_stop;

	//3 8. Initialize t/rx transmit resources
	if(rtw_hal_inirp_init(padapter) ==_FAIL) {
		RT_TRACE(_module_hci_intfs_c_,_drv_err_,("Initialize PCI desc ring Failed!\n"));
		goto free_hal_data;
	}

	//3 9. Disable interrupt before software init
	rtw_hal_disable_interrupt(padapter);

	//3 10. Init driver common data
	if (rtw_init_drv_sw(padapter) == _FAIL) {
		RT_TRACE(_module_hci_intfs_c_, _drv_err_,
			 ("%s: Initialize driver software resource Failed!\n", __FUNCTION__));		
		goto wifi_drv_init_err;
	}
	
 
	//3 11. get WLan MAC address
	// alloc dev name after read efuse.
	rtw_init_netdev_name(pnetdev, (const char*)padapter->registrypriv.ifname); 
	rtw_macaddr_cfg(padapter->eeprompriv.mac_addr);
	rtw_memcpy(pnetdev->dev_addr, padapter->eeprompriv.mac_addr, ETH_ALEN);
	
	DBG_871X("bDriverStopped:%d, bSurpriseRemoved:%d, bup:%d, hw_init_completed:%d\n"
		,padapter->bDriverStopped
		,padapter->bSurpriseRemoved
		,padapter->bup
		,padapter->hw_init_completed
	);
#endif

}


void rtw_read_chip_version(RTW_WIFI_HAL_DATA *pHalData)
{
	u32					value32;
    u8              	value8;


	value32 = HAL_READ32(SYSTEM_CTRL_BASE,REG_SYS_SYSTEM_CFG0);

	memset((void*)pHalData, 0, sizeof(RTW_WIFI_HAL_DATA));
	//ChipVersion.ICType = CHIP_8195A;
	pHalData->ChipType = ((value32 & BIT16) ? TEST_CHIP : NORMAL_CHIP);

	//ChipVersion.RFType = RF_TYPE_1T1R ;
	// pHalData->rf_type = RF_1T1R;
	
    value8 = ((value32 & 0x300) >> 8);
    if (value8 ==  0) {
        pHalData->VendorType = CHIP_VENDOR_TSMC;
    }
    else if (value8 ==  1) {
        pHalData->VendorType = CHIP_VENDOR_SMIC;
    }
    else if (value8 ==  2) {
        pHalData->VendorType = CHIP_VENDOR_UMC;
    }
    
	pHalData->CUTVersion = (HAL_CUT_VERSION_E)((value32 & 0xF0)>> 4); // IC version (CUT)

	// For regulator mode. by tynli. 2011.01.14
	value32 = HAL_READ32(SYSTEM_CTRL_BASE,REG_SYS_SYSTEM_CFG1);
	pHalData->RegulatorMode = ((value32 & BIT25) ? RT_LDO_REGULATOR : RT_SWITCHING_REGULATOR);
	
}


#define	RTL8195A_TRANS_ACT_TO_CARDEMU_STEPS	3
#define	RTL8195A_TRANS_CARDEMU_TO_PDN_STEPS	15
#define	RTL8195A_TRANS_END_STEPS		1

#define RTL8195A_TRANS_CARDDIS_TO_CARDEMU													\
	/* format */																\
	/* { offset, cut_msk, fab_msk|interface_msk, base|cmd, msk, value }, // comments here*/								\


#define RTL8195A_TRANS_CARDEMU_TO_ACT 														\
	/* format */																\
	/* { offset, cut_msk, fab_msk|interface_msk, base|cmd, msk, value }, // comments here*/								\
	{0x0000, PWR_CUT_ALL_MSK, PWR_FAB_ALL_MSK, PWR_INTF_USB_MSK|PWR_INTF_SDIO_MSK,PWR_BASEADDR_MAC,PWR_CMD_WRITE, BIT5, 0}, /*0x00[5] = 1b'0 release analog Ips to digital ,1:isolation*/   \
	{0x0004, PWR_CUT_ALL_MSK, PWR_FAB_ALL_MSK, PWR_INTF_ALL_MSK,PWR_BASEADDR_MAC,PWR_CMD_WRITE, BIT0, 1},\
	{0x0020, PWR_CUT_ALL_MSK, PWR_FAB_ALL_MSK, PWR_INTF_ALL_MSK,PWR_BASEADDR_MAC,PWR_CMD_WRITE, BIT0, 1},\
	{0x0020, PWR_CUT_ALL_MSK, PWR_FAB_ALL_MSK, PWR_INTF_ALL_MSK,PWR_BASEADDR_MAC,PWR_CMD_POLLING, BIT0, 0},/**/	


#define RTL8195A_TRANS_END															\
	/* format */																\
	/* { offset, cut_msk, fab_msk|interface_msk, base|cmd, msk, value }, // comments here*/								\
	{0xFFFF, PWR_CUT_ALL_MSK, PWR_FAB_ALL_MSK, PWR_INTF_ALL_MSK,0,PWR_CMD_END, 0, 0}, //



WLAN_PWR_CFG rtl8195A_card_enable_flow[RTL8195A_TRANS_ACT_TO_CARDEMU_STEPS+RTL8195A_TRANS_CARDEMU_TO_PDN_STEPS+RTL8195A_TRANS_END_STEPS]=
{
	RTL8195A_TRANS_CARDDIS_TO_CARDEMU
	RTL8195A_TRANS_CARDEMU_TO_ACT		
	RTL8195A_TRANS_END
};

void rtw_power_on(RTW_WIFI_HAL_DATA *pHalData)
{
	u16 value16; 
	u8 ret = _FAIL;


	// only cmd52 can be used before power on(card enable)
	//CardEnable(padapter);
	if (pHalData->bMacPwrCtrlOn == _FALSE)
	{
		// RSV_CTRL 0x1C[7:0] = 0x00
		// unlock ISO/CLK/Power control register
		HAL_WL_WRITE8(REG_RSV_CTRL, 0x0);

		ret = HalPwrSeqCmdParsing(PWR_CUT_ALL_MSK, PWR_FAB_ALL_MSK, PWR_INTF_SDIO_MSK, rtl8195A_card_enable_flow);
		if (ret == _SUCCESS) {
			pHalData->bMacPwrCtrlOn = _TRUE;
		}
	}

	if ( pHalData->bMacPwrCtrlOn ) {
	
		value16 = HAL_WL_READ16(REG_CR); // hang at this function

		value16 |= (HCI_TXDMA_EN | HCI_RXDMA_EN | TXDMA_EN | RXDMA_EN
					| PROTOCOL_EN | SCHEDULE_EN | ENSEC | CALTMR_EN);
		HAL_WL_WRITE16(REG_CR, value16);


		//2MAC_TODO
		// TODO: CR register, Enable Schedule; chris
	    {
	        HAL_WL_WRITE32(0x4, HAL_WL_READ32(0x4) | BIT(8));        
	    }
	}
}


#define EFUSE_MAP_LEN_8195A             512

#define	HWSET_MAX_SIZE_512		512
u8		efuse_eeprom_data[HWSET_MAX_SIZE_512];

u8		sMacAddr[6] = {0x00, 0xE0, 0x4C, 0xb7, 0x23, 0x00};

#define EEPROM_DEFAULT_24G_INDEX			0x2D
#define EEPROM_DEFAULT_24G_HT20_DIFF		0X02
#define EEPROM_DEFAULT_24G_OFDM_DIFF		0X04

#define EEPROM_DEFAULT_DIFF					0XFE

#define RT_CHANNEL_DOMAIN_WORLD_WIDE_13 	0x0A

typedef enum {
	TXPWR_LMT_FCC = 0,
	TXPWR_LMT_MKK = 1,
	TXPWR_LMT_ETSI = 2,
	TXPWR_LMT_WW = 3,	

	TXPWR_LMT_MAX_REGULATION_NUM = 4
} REGULATION_TXPWR_LMT;

#define EEPROM_Default_CrystalCap_8195A			0x20

#define VOLTAGE_V25		0x07
#define LDOE25_SHIFT	28

#define	EEPROM_Default_ThermalMeter_8195A		0x1A

void rtw_read_efuse(RTW_WIFI_HAL_DATA *pHalData)
{
	u32		eeValue;
	
	u8		EepromOrEfuse;
	u8		bautoload_fail_flag;
	u16		mapLen=0;
	

	eeValue = HAL_READ32(SYSTEM_CTRL_BASE,REG_SYS_EEPROM_CTRL0);
	EepromOrEfuse = (eeValue & BOOT_FROM_EEPROM) ? _TRUE : _FALSE; // _FALSE
	bautoload_fail_flag = (eeValue & EEPROM_EN) ? _FALSE : _TRUE; // _TRUE

	// set default value for arduino boards
	
	// Hal_InitPGData
	// Read EFUSE real map to shadow.
	//EFUSE_ShadowMapUpdate(padapter, EFUSE_WIFI, _FALSE);
	
	//EFUSE_GetEfuseDefinition(pAdapter, efuseType, TYPE_EFUSE_MAP_LEN, (PVOID)&mapLen, bPseudoTest);
	mapLen = EFUSE_MAP_LEN_8195A;
	
	memset(efuse_eeprom_data, 0xFF, mapLen);
	//rtw_memcpy((void*)PROMContent, (void*)pEEPROM->efuse_eeprom_data, HWSET_MAX_SIZE_8195A);
	//pHalData->EEPROMVersion = 1
	//pHalData->EEPROMRegulatory = 0;

	{
		int			rfPath, ch, TxCount;

		for(rfPath = 0 ; rfPath < MAX_RF_PATH ; rfPath++)
		{
			for(ch = 0 ; ch < CHANNEL_MAX_NUMBER; ch++)
			{
				
				pHalData->Index24G_CCK_Base[rfPath][ch] = EEPROM_DEFAULT_24G_INDEX;
				pHalData->Index24G_BW40_Base[rfPath][ch] = EEPROM_DEFAULT_24G_INDEX;
			}

			
			pHalData->CCK_24G_Diff[rfPath][0]=EEPROM_DEFAULT_DIFF;
			pHalData->OFDM_24G_Diff[rfPath][0]=EEPROM_DEFAULT_24G_OFDM_DIFF;
			pHalData->BW20_24G_Diff[rfPath][0]=EEPROM_DEFAULT_24G_HT20_DIFF;
			pHalData->BW40_24G_Diff[rfPath][0]=EEPROM_DEFAULT_DIFF;
			
			for(TxCount=1;TxCount<MAX_TX_COUNT;TxCount++)
			{
				pHalData->CCK_24G_Diff[rfPath][TxCount]=EEPROM_DEFAULT_DIFF;
				pHalData->OFDM_24G_Diff[rfPath][TxCount]=EEPROM_DEFAULT_DIFF;
				pHalData->BW20_24G_Diff[rfPath][TxCount]=EEPROM_DEFAULT_DIFF;
				pHalData->BW40_24G_Diff[rfPath][TxCount]=EEPROM_DEFAULT_DIFF;
			}
		}
	
	}

	//pHalData->BoardType = 0;
	// padapter->mlmepriv.ChannelPlan =  RT_CHANNEL_DOMAIN_WORLD_WIDE_13

	// pHalData->Regulation2_4G = TXPWR_LMT_WW;
	// pHalData->Regulation5G = TXPWR_LMT_WW;

	
	// pHalData->CrystalCap = EEPROM_Default_CrystalCap_8195A;

	//HalEFUSEPowerSwitch8195AROM(_FALSE, _TRUE, VOLTAGE_V25);
	// pHalData->PackageType = PACKAGE_QFN56;

	// pHalData->bAPKThermalMeterIgnore = _TRUE;	
	// pHalData->EEPROMThermalMeter = EEPROM_Default_ThermalMeter_8195A;

	// pHalData->EEPROMCustomerID = 0;
	// Adapter->eeprompriv.EEPROMRFGainOffset = _FALSE;
	// Adapter->eeprompriv.EEPROMRFGainVal=0xFF;

	//padapter->intf_start = &hci_intf_start;
	//padapter->intf_stop = &hci_intf_stop;

	// rtw_hal_inirp_init

	

}


void rtw_hal_dm_init(RTW_WIFI_HAL_DATA *pHalData)
{
	PDM_ODM_T pOdm = &(pHalData->odmpriv);

	pOdm->SupportPlatform = ODM_CE;
	pOdm->SupportInterface = RTW_LXBUS;
}

#define LX_DMA_IMR_DISABLED 0
#define FW_IMR_DISABLED     0
#define WL_PMC_IMR_DISABLED 0

void rtw_disable_interrupt(void)
{
	u32 LxDmaImr, FwImr, WlPmcImr;

	LxDmaImr = rtk_cpu_to_le32(LX_DMA_IMR_DISABLED);
	HAL_WL_WRITE32(REG_LX_DMA_IMR, LxDmaImr);
	FwImr = rtk_cpu_to_le32(FW_IMR_DISABLED);
	HAL_WL_WRITE32(REG_FWIMR, FwImr);
	WlPmcImr = rtk_cpu_to_le32(WL_PMC_IMR_DISABLED);
	HAL_WL_WRITE32(REG_WL_PMC_IMR, WlPmcImr);
	
}

#else




#define _OS_INTFS_C_


#if defined (PLATFORM_LINUX) && defined (PLATFORM_WINDOWS)

#error "Shall be Linux or Windows, but not both!\n"

#endif

#include <drv_types.h>
//#include <ethernetif.h>


#include "rtw_debug.h"

//TODO
#if 0
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Realtek Wireless Lan Driver");
MODULE_AUTHOR("Realtek Semiconductor Corp.");
MODULE_VERSION(DRIVERVERSION);
#endif	//#if 0

/* module param defaults */
#define rtw_chip_version 		0x00
#define rtw_rfintfs 				HWPI
#define rtw_lbkmode 			0


#define rtw_network_mode 		Ndis802_11IBSS;//Ndis802_11Infrastructure;//infra, ad-hoc, auto	  
//NDIS_802_11_SSID	ssid;
#define rtw_channel 			1	//ad-hoc support requirement 
#define rtw_wireless_mode 		WIRELESS_11BG_24N
#define rtw_vrtl_carrier_sense 	AUTO_VCS
#define rtw_vcs_type 			RTS_CTS
#define rtw_rts_thresh 			2347
#define rtw_preamble 			PREAMBLE_LONG	//long, short, auto
#define rtw_scan_mode 			1				//active, passive
#define rtw_adhoc_tx_pwr 		1
#define rtw_soft_ap 			0
//int smart_ps = 1;  
#ifdef CONFIG_POWER_SAVING
#define  rtw_power_mgnt 		1
#define	 rtw_ps_enable			1
#ifdef CONFIG_IPS_LEVEL_2
#define rtw_ips_mode 			IPS_LEVEL_2
#else
#define rtw_ips_mode			IPS_NORMAL
#endif
#else
#define  rtw_power_mgnt 		PS_MODE_ACTIVE
#define rtw_ips_mode 			IPS_NONE
#endif

#define rtw_smart_ps 			2

#ifdef CONFIG_TX_EARLY_MODE
#define rtw_early_mode			1
#endif

//TODO
#if 0
module_param(rtw_ips_mode, int, 0644);
MODULE_PARM_DESC(rtw_ips_mode,"The default IPS mode");
#endif	//#if 0

#define  rtw_radio_enable		1
#define rtw_long_retry_lmt 		7
#define rtw_short_retry_lmt 		7
#define rtw_busy_thresh 		40
//int qos_enable = 0; //*
#define  rtw_ack_policy 			NORMAL_ACK

#define  rtw_mp_mode 			0

#define rtw_software_encrypt 	0
#define rtw_software_decrypt 	0	  

#define rtw_acm_method 		0		// 0:By SW 1:By HW.
 
#define  rtw_wmm_enable 		1		// default is set to enable the wmm.
#define  rtw_uapsd_enable 		0
#define  rtw_uapsd_max_sp 		NO_LIMIT
#define  rtw_uapsd_acbk_en 		0
#define  rtw_uapsd_acbe_en 		0
#define  rtw_uapsd_acvi_en 		0
#define  rtw_uapsd_acvo_en 		0
	
#ifdef CONFIG_80211N_HT
#define  rtw_ht_enable 			1
#define  rtw_cbw40_enable 		0
#define  rtw_ampdu_enable 		1		//for enable tx_ampdu
#define  rtw_rx_stbc 			1		// 0: disable, bit(0):enable 2.4g, bit(1):enable 5g, default is set to enable 2.4GHZ for IOT issue with bufflao's AP at 5GHZ
#define  rtw_ampdu_amsdu 		0		// 0: disabled, 1:enabled, 2:auto
#endif

#define  rtw_lowrate_two_xmit 	1		//Use 2 path Tx to transmit MCS0~7 and legacy mode

//int rf_config = RF_1T2R;  // 1T2R	
#define  rtw_rf_config 			RF_819X_MAX_TYPE  //auto
#define  rtw_low_power 		0
#ifdef CONFIG_WIFI_TEST
#define  rtw_wifi_spec 			1		//for wifi test
#else
#define  rtw_wifi_spec 			0
#endif
#define  rtw_channel_plan 		RT_CHANNEL_DOMAIN_MAX

#ifdef CONFIG_BT_COEXIST
#define  rtw_btcoex_enable 		1
#define  rtw_bt_iso 			2	// 0:Low, 1:High, 2:From Efuse
#define  rtw_bt_sco 			3	// 0:Idle, 1:None-SCO, 2:SCO, 3:From Counter, 4.Busy, 5.OtherBusy
#define  rtw_bt_ampdu 			1 	// 0:Disable BT control A-MPDU, 1:Enable BT control A-MPDU.
#endif
#ifdef CONFIG_RECV_REORDERING_CTRL
#define  rtw_AcceptAddbaReq 	_TRUE	// 0:Reject AP's Add BA req, 1:Accept AP's Add BA req.
#endif
#define  rtw_antdiv_cfg 			2 	// 0:OFF , 1:ON, 2:decide by Efuse config
#define  rtw_antdiv_type 		0 	//0:decide by efuse  1: for 88EE, 1Tx and 1RxCG are diversity.(2 Ant with SPDT), 2:  for 88EE, 1Tx and 2Rx are diversity.( 2 Ant, Tx and RxCG are both on aux port, RxCS is on main port ), 3: for 88EE, 1Tx and 1RxCG are fixed.(1Ant, Tx and RxCG are both on aux port)


#ifdef CONFIG_USB_AUTOSUSPEND
#define  rtw_enusbss 			1	//0:disable,1:enable
#else
#define  rtw_enusbss 			0	//0:disable,1:enable
#endif

#define  rtw_hwpdn_mode		2	//0:disable,1:enable,2: by EFUSE config

#ifdef CONFIG_HW_PWRP_DETECTION
#define  rtw_hwpwrp_detect 		1 
#else
#define  rtw_hwpwrp_detect 		0	 //HW power  ping detect 0:disable , 1:enable
#endif

#ifdef CONFIG_USB_HCI
#define  rtw_hw_wps_pbc 		1
#else
#define  rtw_hw_wps_pbc 		0	
#endif

#ifdef CONFIG_TX_MCAST2UNI
#define  rtw_mc2u_disable 		0
#endif	// CONFIG_TX_MCAST2UNI

#ifdef CONFIG_DUALMAC_CONCURRENT
#define  rtw_dmsp 				0
#endif	// CONFIG_DUALMAC_CONCURRENT
#ifdef CONFIG_80211D
#define  rtw_80211d 			0
#endif

#ifdef CONFIG_SPECIAL_SETTING_FOR_FUNAI_TV
#define  rtw_force_ant 			2	//0 :normal, 1:Main ant, 2:Aux ant
#define  rtw_force_igi 			0	//0 :normal
module_param(rtw_force_ant, int, 0644);
module_param(rtw_force_igi, int, 0644);
#endif

char* ifname = "wlan%d";

//TODO
//module_param(ifname, charp, 0644);
//MODULE_PARM_DESC(ifname, "The default name to allocate for first interface");

char* if2name = "wlan%d";

//TODO
//module_param(if2name, charp, 0644);
//MODULE_PARM_DESC(if2name, "The default name to allocate for second interface");

char* rtw_initmac = 0;  // temp mac address if users want to use instead of the mac address in Efuse

typedef int (*init_done_ptr)(void);
init_done_ptr p_init_done_callback;

//TODO
#if 0

module_param(rtw_initmac, charp, 0644);
module_param(rtw_channel_plan, int, 0644);
module_param(rtw_chip_version, int, 0644);
module_param(rtw_rfintfs, int, 0644);
module_param(rtw_lbkmode, int, 0644);
module_param(rtw_network_mode, int, 0644);
module_param(rtw_channel, int, 0644);
module_param(rtw_mp_mode, int, 0644);
module_param(rtw_wmm_enable, int, 0644);
module_param(rtw_vrtl_carrier_sense, int, 0644);
module_param(rtw_vcs_type, int, 0644);
module_param(rtw_busy_thresh, int, 0644);
#ifdef CONFIG_80211N_HT
module_param(rtw_ht_enable, int, 0644);
module_param(rtw_cbw40_enable, int, 0644);
module_param(rtw_ampdu_enable, int, 0644);
module_param(rtw_rx_stbc, int, 0644);
module_param(rtw_ampdu_amsdu, int, 0644);
#endif

module_param(rtw_lowrate_two_xmit, int, 0644);

module_param(rtw_rf_config, int, 0644);
module_param(rtw_power_mgnt, int, 0644);
module_param(rtw_smart_ps, int, 0644);
module_param(rtw_low_power, int, 0644);
module_param(rtw_wifi_spec, int, 0644);

module_param(rtw_antdiv_cfg, int, 0644);
module_param(rtw_antdiv_type, int, 0644);

module_param(rtw_enusbss, int, 0644);
module_param(rtw_hwpdn_mode, int, 0644);
module_param(rtw_hwpwrp_detect, int, 0644);

module_param(rtw_hw_wps_pbc, int, 0644);

#ifdef CONFIG_TX_EARLY_MODE
module_param(rtw_early_mode, int, 0644);
#endif
#ifdef CONFIG_ADAPTOR_INFO_CACHING_FILE
char *rtw_adaptor_info_caching_file_path= "/data/misc/wifi/rtw_cache";
module_param(rtw_adaptor_info_caching_file_path, charp, 0644);
MODULE_PARM_DESC(rtw_adaptor_info_caching_file_path, "The path of adapter info cache file");
#endif //CONFIG_ADAPTOR_INFO_CACHING_FILE

#ifdef CONFIG_LAYER2_ROAMING
uint rtw_max_roaming_times=2;
module_param(rtw_max_roaming_times, uint, 0644);
MODULE_PARM_DESC(rtw_max_roaming_times,"The max roaming times to try");
#endif //CONFIG_LAYER2_ROAMING

#ifdef CONFIG_IOL
bool rtw_force_iol=_FALSE;
module_param(rtw_force_iol, bool, 0644);
MODULE_PARM_DESC(rtw_force_iol,"Force to enable IOL");
#endif //CONFIG_IOL

#ifdef CONFIG_FILE_FWIMG
char *rtw_fw_file_path= "";
module_param(rtw_fw_file_path, charp, 0644);
MODULE_PARM_DESC(rtw_fw_file_path, "The path of fw image");
#endif //CONFIG_FILE_FWIMG

#ifdef CONFIG_TX_MCAST2UNI
module_param(rtw_mc2u_disable, int, 0644);
#endif	// CONFIG_TX_MCAST2UNI

#ifdef CONFIG_DUALMAC_CONCURRENT
module_param(rtw_dmsp, int, 0644);
#endif	// CONFIG_DUALMAC_CONCURRENT
#ifdef CONFIG_80211D
module_param(rtw_80211d, int, 0644);
MODULE_PARM_DESC(rtw_80211d, "Enable 802.11d mechanism");
#endif

#ifdef CONFIG_BT_COEXIST
module_param(rtw_btcoex_enable, int, 0644);
MODULE_PARM_DESC(rtw_btcoex_enable, "Enable BT co-existence mechanism");
#endif

#endif	//#if 0

#define rtw_notch_filter 			RTW_NOTCH_FILTER
#define rtw_adaptivity_en			CONFIG_RTW_ADAPTIVITY_EN
#define rtw_adaptivity_mode			CONFIG_RTW_ADAPTIVITY_MODE
#define rtw_adaptivity_dml			CONFIG_RTW_ADAPTIVITY_DML
#define rtw_adaptivity_dc_backoff	CONFIG_RTW_ADAPTIVITY_DC_BACKOFF
#define rtw_nhm_en					CONFIG_RTW_NHM_EN

#define rtw_tx_pwr_lmt_enable		0
#define rtw_tx_pwr_by_rate			2	// 2- Depend on efuse(flash)

//TODO
//module_param(rtw_notch_filter, uint, 0644);
//MODULE_PARM_DESC(rtw_notch_filter, "0:Disable, 1:Enable, 2:Enable only for P2P");

static uint loadparam(PADAPTER padapter, _nic_hdl pnetdev);
int _netdev_open(struct net_device *pnetdev);
int netdev_open (struct net_device *pnetdev);
static int netdev_close (struct net_device *pnetdev);
int rtw_xmit_entry(_pkt *pkt, _nic_hdl pnetdev);
int rtw_os_can_xmit(struct net_device *dev);
extern int rtw_ioctl(struct net_device *dev, struct iwreq *rq, int cmd);

extern void rtw_indicate_wx_assoc_event(_adapter *padapter);
extern void rtw_indicate_wx_disassoc_event(_adapter *padapter);

void rtw_os_indicate_connect(_adapter *adapter)
{

_func_enter_;	

#ifdef CONFIG_IOCTL_CFG80211
	rtw_cfg80211_indicate_connect(adapter);
#endif //CONFIG_IOCTL_CFG80211

	rtw_indicate_wx_assoc_event(adapter);

#ifdef RTK_DMP_PLATFORM
	_set_workitem(&adapter->mlmepriv.Linkup_workitem);
#endif

_func_exit_;	

}


extern void indicate_wx_scan_complete_event(_adapter *padapter);
void rtw_os_indicate_scan_done( _adapter *padapter, bool aborted)
{
#ifdef CONFIG_IOCTL_CFG80211
	rtw_cfg80211_indicate_scan_done(wdev_to_priv(padapter->rtw_wdev), aborted);
#else
	indicate_wx_scan_complete_event(padapter);
#endif
}

#ifdef CONFIG_WPA2_PREAUTH
static RT_PMKID_LIST   backupPMKIDList[ NUM_PMKID_CACHE ];
#endif
void rtw_reset_securitypriv( _adapter *adapter )
{
//	u8	backupPMKIDIndex = 0;
	u8	backupTKIPCountermeasure = 0x00;
	u32	backupTKIPcountermeasure_time = 0;
	u8 	*palloc_wpastainfo_buf = NULL;
	u32	alloc_wpastainfo_size = 0;
	int i;

	if(adapter->securitypriv.dot11AuthAlgrthm == dot11AuthAlgrthm_8021X)//802.1x
	{		 
#ifdef CONFIG_WPA2_PREAUTH
		// Added by Albert 2009/02/18
		// We have to backup the PMK information for WiFi PMK Caching test item.
		rtw_memset( &backupPMKIDList[ 0 ], 0x00, sizeof( RT_PMKID_LIST ) * NUM_PMKID_CACHE );

		rtw_memcpy( &backupPMKIDList[ 0 ], &adapter->securitypriv.PMKIDList[ 0 ], sizeof( RT_PMKID_LIST ) * NUM_PMKID_CACHE );
		backupPMKIDIndex = adapter->securitypriv.PMKIDIndex;
#endif
		// Backup the btkip_countermeasure information.
		// When the countermeasure is trigger, the driver have to disconnect with AP for 60 seconds.
		backupTKIPCountermeasure = adapter->securitypriv.btkip_countermeasure;
		backupTKIPcountermeasure_time = adapter->securitypriv.btkip_countermeasure_time;		
#ifdef CONFIG_INCLUDE_WPA_PSK
#if defined(CONFIG_AP_MODE) && defined(CONFIG_MULTIPLE_WPA_STA)
{
		for(i = 0; i < AP_STA_NUM; i ++)
			rtw_cancel_timer(&adapter->securitypriv.wpa_sta_info[i]->resendTimer);
}
#else
		rtw_cancel_timer(&adapter->securitypriv.wpa_sta_info.resendTimer);
#endif
#ifdef CONFIG_GK_REKEY
		rtw_cancel_timer(&adapter->securitypriv.wpa_global_info.GKRekeyTimer);
#endif
#endif
#if defined(CONFIG_AP_MODE) && defined(CONFIG_MULTIPLE_WPA_STA)
		palloc_wpastainfo_buf = adapter->securitypriv.palloc_wpastainfo_buf;
		alloc_wpastainfo_size = adapter->securitypriv.alloc_wpastainfo_size;
#endif
		rtw_memset((unsigned char *)&adapter->securitypriv, 0, sizeof (struct security_priv));
		//rtw_init_timer(&(adapter->securitypriv.tkip_timer),adapter->pnetdev, rtw_use_tkipkey_handler, adapter, "tkip_timer");
#if defined(CONFIG_AP_MODE) && defined(CONFIG_MULTIPLE_WPA_STA)
		adapter->securitypriv.palloc_wpastainfo_buf = palloc_wpastainfo_buf;
		adapter->securitypriv.alloc_wpastainfo_size = alloc_wpastainfo_size;
		adapter->securitypriv.wpa_sta_info[0] = (WPA_STA_INFO*)(palloc_wpastainfo_buf + 4 - 
			((SIZE_PTR)(palloc_wpastainfo_buf) & 3));
		for(i=1; i<(alloc_wpastainfo_size/sizeof(WPA_STA_INFO)); i++)
		{
			adapter->securitypriv.wpa_sta_info[i] = (WPA_STA_INFO*)((u8*)adapter->securitypriv.wpa_sta_info[0] + sizeof(WPA_STA_INFO)*i);
			DBG_871X("rtw_reset_securitypriv(): wpa_sta_info[%d]= %p\n", i, adapter->securitypriv.wpa_sta_info[i]);
		}
#endif
#ifdef CONFIG_WPA2_PREAUTH
		// Added by Albert 2009/02/18
		// Restore the PMK information to securitypriv structure for the following connection.
		rtw_memcpy( &adapter->securitypriv.PMKIDList[ 0 ], &backupPMKIDList[ 0 ], sizeof( RT_PMKID_LIST ) * NUM_PMKID_CACHE );
		adapter->securitypriv.PMKIDIndex = backupPMKIDIndex;
#endif
		adapter->securitypriv.btkip_countermeasure = backupTKIPCountermeasure;
		adapter->securitypriv.btkip_countermeasure_time = backupTKIPcountermeasure_time;		

		adapter->securitypriv.ndisauthtype = Ndis802_11AuthModeOpen;
		adapter->securitypriv.ndisencryptstatus = Ndis802_11WEPDisabled;

	}
	else //reset values in securitypriv 
	{
		//if(adapter->mlmepriv.fw_state & WIFI_STATION_STATE)
		//{
		struct security_priv *psec_priv=&adapter->securitypriv;

		psec_priv->dot11AuthAlgrthm =dot11AuthAlgrthm_Open;  //open system
		psec_priv->dot11PrivacyAlgrthm = _NO_PRIVACY_;
		psec_priv->dot11PrivacyKeyIndex = 0;

		psec_priv->dot118021XGrpPrivacy = _NO_PRIVACY_;
		psec_priv->dot118021XGrpKeyid = 1;

		psec_priv->ndisauthtype = Ndis802_11AuthModeOpen;
		psec_priv->ndisencryptstatus = Ndis802_11WEPDisabled;
		//}
	}
}

void rtw_os_indicate_disconnect( _adapter *adapter )
{
   //RT_PMKID_LIST   backupPMKIDList[ NUM_PMKID_CACHE ];
  
_func_enter_;
//TODO
//	netif_carrier_off(adapter->pnetdev); // Do it first for tx broadcast pkt after disconnection issue!

#ifdef CONFIG_IOCTL_CFG80211
	rtw_cfg80211_indicate_disconnect(adapter);
#endif //CONFIG_IOCTL_CFG80211
//TODO
	rtw_indicate_wx_disassoc_event(adapter);

#ifdef RTK_DMP_PLATFORM
	_set_workitem(&adapter->mlmepriv.Linkdown_workitem);
#endif

	/* clear key */
	if (adapter->securitypriv.dot11PrivacyKeyIndex < 4) {
		/* hw key */
		rtw_clearstakey_cmd(adapter, NULL, adapter->securitypriv.dot11PrivacyKeyIndex, 0);

		/* sw key */
		rtw_memset(&adapter->securitypriv.dot11DefKey[adapter->securitypriv.dot11PrivacyKeyIndex], 0, 16);
		adapter->securitypriv.dot11DefKeylen[adapter->securitypriv.dot11PrivacyKeyIndex] = 0;
	}

	rtw_reset_securitypriv( adapter );

_func_exit_;

}

//#ifdef RTK_DMP_PLATFORM
#ifdef CONFIG_PROC_DEBUG
#define RTL8192C_PROC_NAME "rtl819xC"
#define RTL8192D_PROC_NAME "rtl819xD"
static char rtw_proc_name[IFNAMSIZ];
static struct proc_dir_entry *rtw_proc = NULL;
static int	rtw_proc_cnt = 0;

#define RTW_PROC_NAME DRV_NAME

void rtw_proc_init_one(struct net_device *dev)
{
	struct proc_dir_entry *dir_dev = NULL;
	struct proc_dir_entry *entry=NULL;
	_adapter	*padapter = rtw_netdev_priv(dev);
	u8 rf_type;

	if(rtw_proc == NULL)
	{
		if(padapter->chip_type == RTL8188C_8192C)
		{
			rtw_memcpy(rtw_proc_name, RTL8192C_PROC_NAME, sizeof(RTL8192C_PROC_NAME));
		}
		else if(padapter->chip_type == RTL8192D)
		{
			rtw_memcpy(rtw_proc_name, RTL8192D_PROC_NAME, sizeof(RTL8192D_PROC_NAME));
		}
		else if(padapter->chip_type == RTL8723A)
		{
			rtw_memcpy(rtw_proc_name, RTW_PROC_NAME, sizeof(RTW_PROC_NAME));
		}
		else if(padapter->chip_type == RTL8188E)
		{
			rtw_memcpy(rtw_proc_name, RTW_PROC_NAME, sizeof(RTW_PROC_NAME));
		}
		else
		{
			rtw_memcpy(rtw_proc_name, RTW_PROC_NAME, sizeof(RTW_PROC_NAME));
		}		

#if(LINUX_VERSION_CODE < KERNEL_VERSION(2,6,24))
		rtw_proc=create_proc_entry(rtw_proc_name, S_IFDIR, proc_net);
#else
		rtw_proc=create_proc_entry(rtw_proc_name, S_IFDIR, init_net.proc_net);
#endif
		if (rtw_proc == NULL) {
			DBG_871X(KERN_ERR "Unable to create rtw_proc directory\n");
			return;
		}

		entry = create_proc_read_entry("ver_info", S_IFREG | S_IRUGO, rtw_proc, proc_get_drv_version, dev);				   
		if (!entry) {
			DBG_871X("Unable to create_proc_read_entry!\n"); 
			return;
		}
	}

	

	if(padapter->dir_dev == NULL)
	{
		padapter->dir_dev = create_proc_entry(dev->name, 
					  S_IFDIR | S_IRUGO | S_IXUGO, 
					  rtw_proc);

		dir_dev = padapter->dir_dev;

		if(dir_dev==NULL)
		{
			if(rtw_proc_cnt == 0)
			{
				if(rtw_proc){
#if(LINUX_VERSION_CODE < KERNEL_VERSION(2,6,24))
					remove_proc_entry(rtw_proc_name, proc_net);
#else
					remove_proc_entry(rtw_proc_name, init_net.proc_net);
#endif		
					rtw_proc = NULL;
				}
			}

			DBG_871X("Unable to create dir_dev directory\n");
			return;
		}
	}
	else
	{
		return;
	}

	rtw_proc_cnt++;

	entry = create_proc_read_entry("write_reg", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_write_reg, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}
	entry->write_proc = proc_set_write_reg;

	entry = create_proc_read_entry("read_reg", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_read_reg, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}
	entry->write_proc = proc_set_read_reg;

	
	entry = create_proc_read_entry("fwstate", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_fwstate, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}


	entry = create_proc_read_entry("sec_info", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_sec_info, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}


	entry = create_proc_read_entry("mlmext_state", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_mlmext_state, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}


	entry = create_proc_read_entry("qos_option", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_qos_option, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}

	entry = create_proc_read_entry("ht_option", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_ht_option, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}

	entry = create_proc_read_entry("rf_info", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_rf_info, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}
	
	entry = create_proc_read_entry("ap_info", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_ap_info, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}

	entry = create_proc_read_entry("adapter_state", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_adapter_state, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}

	entry = create_proc_read_entry("trx_info", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_trx_info, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}

	entry = create_proc_read_entry("mac_reg_dump1", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_mac_reg_dump1, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}

	entry = create_proc_read_entry("mac_reg_dump2", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_mac_reg_dump2, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}

	entry = create_proc_read_entry("mac_reg_dump3", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_mac_reg_dump3, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}
	
	entry = create_proc_read_entry("bb_reg_dump1", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_bb_reg_dump1, dev);	   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}

	entry = create_proc_read_entry("bb_reg_dump2", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_bb_reg_dump2, dev);	   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}

	entry = create_proc_read_entry("bb_reg_dump3", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_bb_reg_dump3, dev);	   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}

	entry = create_proc_read_entry("rf_reg_dump1", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_rf_reg_dump1, dev);
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}

	entry = create_proc_read_entry("rf_reg_dump2", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_rf_reg_dump2, dev);
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}
	
	rtw_hal_get_hwreg(padapter, HW_VAR_RF_TYPE, (u8 *)(&rf_type));	
	if((RF_1T2R == rf_type) ||(RF_1T1R ==rf_type ))	{
		entry = create_proc_read_entry("rf_reg_dump3", S_IFREG | S_IRUGO,
					   dir_dev, proc_get_rf_reg_dump3, dev);
		if (!entry) {
			DBG_871X("Unable to create_proc_read_entry!\n"); 
			return;
		}

		entry = create_proc_read_entry("rf_reg_dump4", S_IFREG | S_IRUGO,
					   dir_dev, proc_get_rf_reg_dump4, dev);
		if (!entry) {
			DBG_871X("Unable to create_proc_read_entry!\n"); 
			return;
		}
	}
	
#ifdef CONFIG_AP_MODE

	entry = create_proc_read_entry("all_sta_info", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_all_sta_info, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}
#endif

#ifdef DBG_MEMORY_LEAK
	entry = create_proc_read_entry("_malloc_cnt", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_malloc_cnt, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}
#endif

#ifdef CONFIG_FIND_BEST_CHANNEL
	entry = create_proc_read_entry("best_channel", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_best_channel, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}
#endif

	entry = create_proc_read_entry("rx_signal", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_rx_signal, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}
	entry->write_proc = proc_set_rx_signal;
#ifdef CONFIG_80211N_HT
	entry = create_proc_read_entry("cbw40_enable", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_cbw40_enable, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}
	entry->write_proc = proc_set_cbw40_enable;
	
	entry = create_proc_read_entry("ampdu_enable", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_ampdu_enable, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}
	entry->write_proc = proc_set_ampdu_enable;
	
	entry = create_proc_read_entry("rx_stbc", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_rx_stbc, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}
	entry->write_proc = proc_set_rx_stbc;
#endif //CONFIG_80211N_HT
	
	entry = create_proc_read_entry("path_rssi", S_IFREG | S_IRUGO,
					dir_dev, proc_get_two_path_rssi, dev);	
	

	entry = create_proc_read_entry("rssi_disp", S_IFREG | S_IRUGO,
				   dir_dev, proc_get_rssi_disp, dev);				   
	if (!entry) {
		DBG_871X("Unable to create_proc_read_entry!\n"); 
		return;
	}
	entry->write_proc = proc_set_rssi_disp;

}

void rtw_proc_remove_one(struct net_device *dev)
{
	struct proc_dir_entry *dir_dev = NULL;
	_adapter	*padapter = rtw_netdev_priv(dev);
	u8 rf_type;

	dir_dev = padapter->dir_dev;
	padapter->dir_dev = NULL;

	if (dir_dev) {

		remove_proc_entry("write_reg", dir_dev);
		remove_proc_entry("read_reg", dir_dev);
		remove_proc_entry("fwstate", dir_dev);
		remove_proc_entry("sec_info", dir_dev);
		remove_proc_entry("mlmext_state", dir_dev);
		remove_proc_entry("qos_option", dir_dev);
		remove_proc_entry("ht_option", dir_dev);
		remove_proc_entry("rf_info", dir_dev);		
		remove_proc_entry("ap_info", dir_dev);
		remove_proc_entry("adapter_state", dir_dev);
		remove_proc_entry("trx_info", dir_dev);

		remove_proc_entry("mac_reg_dump1", dir_dev);
		remove_proc_entry("mac_reg_dump2", dir_dev);
		remove_proc_entry("mac_reg_dump3", dir_dev);
		remove_proc_entry("bb_reg_dump1", dir_dev);
		remove_proc_entry("bb_reg_dump2", dir_dev);
		remove_proc_entry("bb_reg_dump3", dir_dev);
		remove_proc_entry("rf_reg_dump1", dir_dev);
		remove_proc_entry("rf_reg_dump2", dir_dev);
		rtw_hal_get_hwreg(padapter, HW_VAR_RF_TYPE, (u8 *)(&rf_type));	
		if((RF_1T2R == rf_type) ||(RF_1T1R ==rf_type ))	{
			remove_proc_entry("rf_reg_dump3", dir_dev);
			remove_proc_entry("rf_reg_dump4", dir_dev);
		}
#ifdef CONFIG_AP_MODE	
		remove_proc_entry("all_sta_info", dir_dev);
#endif		

#ifdef DBG_MEMORY_LEAK
		remove_proc_entry("_malloc_cnt", dir_dev);
#endif 

#ifdef CONFIG_FIND_BEST_CHANNEL
		remove_proc_entry("best_channel", dir_dev);
#endif 
		remove_proc_entry("rx_signal", dir_dev);
#ifdef CONFIG_80211N_HT
		remove_proc_entry("cbw40_enable", dir_dev);
		
		remove_proc_entry("ampdu_enable", dir_dev);

		remove_proc_entry("rx_stbc", dir_dev);
#endif //CONFIG_80211N_HT
		remove_proc_entry("path_rssi", dir_dev);

		remove_proc_entry("rssi_disp", dir_dev);

		remove_proc_entry(dev->name, rtw_proc);
		dir_dev = NULL;
		
	}
	else
	{
		return;
	}

	rtw_proc_cnt--;

	if(rtw_proc_cnt == 0)
	{
		if(rtw_proc){
			remove_proc_entry("ver_info", rtw_proc);
			
#if(LINUX_VERSION_CODE < KERNEL_VERSION(2,6,24))
			remove_proc_entry(rtw_proc_name, proc_net);
#else
			remove_proc_entry(rtw_proc_name, init_net.proc_net);
#endif		
			rtw_proc = NULL;
		}
	}
}
#endif

uint loadparam( _adapter *padapter,  _nic_hdl	pnetdev)
{
       
	uint status = _SUCCESS;
	struct registry_priv  *registry_par = &padapter->registrypriv;

_func_enter_;

	registry_par->chip_version = (u8)rtw_chip_version;
	registry_par->rfintfs = (u8)rtw_rfintfs;
	registry_par->lbkmode = (u8)rtw_lbkmode;	
	//registry_par->hci = (u8)hci;
	registry_par->network_mode  = (u8)rtw_network_mode;	

	rtw_memcpy(registry_par->ssid.Ssid, "ANY", 3);
	registry_par->ssid.SsidLength = 3;
	
	registry_par->channel = (u8)rtw_channel;
	registry_par->wireless_mode = (u8)rtw_wireless_mode;
	registry_par->vrtl_carrier_sense = (u8)rtw_vrtl_carrier_sense ;
	registry_par->vcs_type = (u8)rtw_vcs_type;
	registry_par->rts_thresh=(u16)rtw_rts_thresh;
	registry_par->preamble = (u8)rtw_preamble;
	registry_par->scan_mode = (u8)rtw_scan_mode;
	registry_par->adhoc_tx_pwr = (u8)rtw_adhoc_tx_pwr;
	registry_par->soft_ap=  (u8)rtw_soft_ap;
	registry_par->smart_ps =  (u8)rtw_smart_ps;  
	registry_par->power_mgnt = (u8)rtw_power_mgnt;
	registry_par->ips_mode = (u8)rtw_ips_mode;
	registry_par->ps_enable = (u8)rtw_ps_enable;
	registry_par->radio_enable = (u8)rtw_radio_enable;
	registry_par->long_retry_lmt = (u8)rtw_long_retry_lmt;
	registry_par->short_retry_lmt = (u8)rtw_short_retry_lmt;
  	registry_par->busy_thresh = (u16)rtw_busy_thresh;
  	//registry_par->qos_enable = (u8)rtw_qos_enable;
	registry_par->ack_policy = (u8)rtw_ack_policy;
	registry_par->mp_mode = (u8)rtw_mp_mode;	
	registry_par->software_encrypt = (u8)rtw_software_encrypt;
	registry_par->software_decrypt = (u8)rtw_software_decrypt;	  

	registry_par->acm_method = (u8)rtw_acm_method;

	 //UAPSD
	registry_par->wmm_enable = (u8)rtw_wmm_enable;
	registry_par->uapsd_enable = (u8)rtw_uapsd_enable;	  
	registry_par->uapsd_max_sp = (u8)rtw_uapsd_max_sp;
	registry_par->uapsd_acbk_en = (u8)rtw_uapsd_acbk_en;
	registry_par->uapsd_acbe_en = (u8)rtw_uapsd_acbe_en;
	registry_par->uapsd_acvi_en = (u8)rtw_uapsd_acvi_en;
	registry_par->uapsd_acvo_en = (u8)rtw_uapsd_acvo_en;

	registry_par->beacon_period = 100;

#ifdef CONFIG_80211N_HT
	registry_par->ht_enable = (u8)rtw_ht_enable;
	registry_par->cbw40_enable = (u8)rtw_cbw40_enable;
	registry_par->ampdu_enable = (u8)rtw_ampdu_enable;
	registry_par->rx_stbc = (u8)rtw_rx_stbc;	
	registry_par->ampdu_amsdu = (u8)rtw_ampdu_amsdu;
#endif
#ifdef CONFIG_TX_EARLY_MODE
	registry_par->early_mode = (u8)rtw_early_mode;
#endif
	registry_par->lowrate_two_xmit = (u8)rtw_lowrate_two_xmit;
	registry_par->rf_config = (u8)rtw_rf_config;
	registry_par->low_power = (u8)rtw_low_power;

	
	registry_par->wifi_spec = (u8)rtw_wifi_spec;

	registry_par->channel_plan = (u8)rtw_channel_plan;

#ifdef CONFIG_BT_COEXIST
	registry_par->btcoex = (u8)rtw_btcoex_enable;
	registry_par->bt_iso = (u8)rtw_bt_iso;
	registry_par->bt_sco = (u8)rtw_bt_sco;
	registry_par->bt_ampdu = (u8)rtw_bt_ampdu;
#endif
#ifdef CONFIG_RECV_REORDERING_CTRL
	registry_par->bAcceptAddbaReq = (u8)rtw_AcceptAddbaReq;
#endif
	registry_par->antdiv_cfg = (u8)rtw_antdiv_cfg;
	registry_par->antdiv_type = (u8)rtw_antdiv_type;

#ifdef CONFIG_AUTOSUSPEND
	registry_par->usbss_enable = (u8)rtw_enusbss;//0:disable,1:enable
#endif
#ifdef SUPPORT_HW_RFOFF_DETECTED
	registry_par->hwpdn_mode = (u8)rtw_hwpdn_mode;//0:disable,1:enable,2:by EFUSE config
	registry_par->hwpwrp_detect = (u8)rtw_hwpwrp_detect;//0:disable,1:enable
#endif

	registry_par->hw_wps_pbc = (u8)rtw_hw_wps_pbc;

#ifdef CONFIG_ADAPTOR_INFO_CACHING_FILE
	snprintf(registry_par->adaptor_info_caching_file_path, PATH_LENGTH_MAX, "%s", rtw_adaptor_info_caching_file_path);
	registry_par->adaptor_info_caching_file_path[PATH_LENGTH_MAX-1]=0;
#endif

#ifdef CONFIG_LAYER2_ROAMING
	registry_par->max_roaming_times = (u8)rtw_max_roaming_times;
#endif

#ifdef CONFIG_IOL
	registry_par->force_iol = rtw_force_iol;
#endif

#ifdef CONFIG_DUALMAC_CONCURRENT
	registry_par->dmsp= (u8)rtw_dmsp;
#endif

#ifdef CONFIG_80211D
	registry_par->enable80211d = (u8)rtw_80211d;
#endif

#if defined(CONFIG_RTL8195A) || defined(CONFIG_RTL8711B)
	snprintf((char *)(registry_par->ifname), 16, "wlan1");
	snprintf((char *)(registry_par->if2name), 16, "wlan2");
#else
	//snprintf((char *)registry_par->ifname, 16, "%s", ifname);
	//snprintf((char *)registry_par->if2name, 16, "%s", if2name);
	snprintf((char *)(registry_par->ifname), 16, "wlan0");
	snprintf((char *)(registry_par->if2name), 16, "wlan1");
#endif

	registry_par->notch_filter = (u8)rtw_notch_filter;

#ifdef CONFIG_SPECIAL_SETTING_FOR_FUNAI_TV
	registry_par->force_ant = (u8)rtw_force_ant;
	registry_par->force_igi = (u8)rtw_force_igi;
#endif

	registry_par->RegEnableTxPowerLimit = (u8)rtw_tx_pwr_lmt_enable;
	registry_par->RegEnableTxPowerByRate = (u8)rtw_tx_pwr_by_rate;
 
	registry_par->adaptivity_en = (u8)rtw_adaptivity_en;
	registry_par->adaptivity_mode = (u8)rtw_adaptivity_mode;
	registry_par->adaptivity_dml = (u8)rtw_adaptivity_dml;
	registry_par->adaptivity_dc_backoff = (u8)rtw_adaptivity_dc_backoff;
	
	registry_par->nhm_en = (u8)rtw_nhm_en;

_func_exit_;

	return status;
}

//TODO
#if 0

static int rtw_net_set_mac_address(struct net_device *pnetdev, void *p)
{
	_adapter *padapter = (_adapter *)rtw_netdev_priv(pnetdev);
	struct sockaddr *addr = p;
	
	if(padapter->bup == _FALSE)
	{
		//DBG_871X("r8711_net_set_mac_address(), MAC=%x:%x:%x:%x:%x:%x\n", addr->sa_data[0], addr->sa_data[1], addr->sa_data[2], addr->sa_data[3],
		//addr->sa_data[4], addr->sa_data[5]);
		rtw_memcpy(padapter->eeprompriv.mac_addr, addr->sa_data, ETH_ALEN);
		//rtw_memcpy(pnetdev->dev_addr, addr->sa_data, ETH_ALEN);
		//padapter->bset_hwaddr = _TRUE;
	}

	return 0;
}

#endif

//extern char* ifname;
static drv_priv drvpriv = {
0
};

static struct net_device_stats *rtw_net_get_stats(struct net_device *pnetdev)
{
	_adapter *padapter = (_adapter *)rtw_netdev_priv(pnetdev);
	struct xmit_priv *pxmitpriv = &(padapter->xmitpriv);
	struct recv_priv *precvpriv = &(padapter->recvpriv);

	padapter->stats.tx_packets = pxmitpriv->tx_pkts;//pxmitpriv->tx_pkts++;
	padapter->stats.rx_packets = precvpriv->rx_pkts;//precvpriv->rx_pkts++; 		
	padapter->stats.tx_dropped = pxmitpriv->tx_drop;
	padapter->stats.rx_dropped = precvpriv->rx_drop;
	padapter->stats.tx_bytes = pxmitpriv->tx_bytes;
	padapter->stats.rx_bytes = precvpriv->rx_bytes;
	
	return &padapter->stats;
}

//TODO
#if 0

#if (LINUX_VERSION_CODE>=KERNEL_VERSION(2,6,35))
/*
 * AC to queue mapping
 *
 * AC_VO -> queue 0
 * AC_VI -> queue 1
 * AC_BE -> queue 2
 * AC_BK -> queue 3
 */
static const u16 rtw_1d_to_queue[8] = { 2, 3, 3, 2, 1, 1, 0, 0 };

/* Given a data frame determine the 802.1p/1d tag to use. */
unsigned int rtw_classify8021d(struct sk_buff *skb)
{
	unsigned int dscp;

	/* skb->priority values from 256->263 are magic values to
	 * directly indicate a specific 802.1d priority.  This is used
	 * to allow 802.1d priority to be passed directly in from VLAN
	 * tags, etc.
	 */
	if (skb->priority >= 256 && skb->priority <= 263)
		return skb->priority - 256;

	switch (skb->protocol) {
	case _htons(ETH_P_IP):
		dscp = ip_hdr(skb)->tos & 0xfc;
		break;
	default:
		return 0;
	}

	return dscp >> 5;
}

static u16 rtw_select_queue(struct net_device *dev, struct sk_buff *skb)
{
	_adapter	*padapter = rtw_netdev_priv(dev);
	struct mlme_priv *pmlmepriv = &padapter->mlmepriv;

	skb->priority = rtw_classify8021d(skb);

	if(pmlmepriv->acm_mask != 0)
	{
		skb->priority = qos_acm(pmlmepriv->acm_mask, skb->priority);
	}

	return rtw_1d_to_queue[skb->priority];
}
#endif

#if (LINUX_VERSION_CODE>=KERNEL_VERSION(2,6,29))
static const struct net_device_ops rtw_netdev_ops = {
	.ndo_open = netdev_open,
	.ndo_stop = netdev_close,
	.ndo_start_xmit = rtw_xmit_entry,
#if (LINUX_VERSION_CODE>=KERNEL_VERSION(2,6,35))
	.ndo_select_queue	= rtw_select_queue,
#endif
	.ndo_set_mac_address = rtw_net_set_mac_address,
	.ndo_get_stats = rtw_net_get_stats,
	.ndo_do_ioctl = rtw_ioctl,
};
#endif

#endif	//#if 0

int rtw_init_netdev_name(struct net_device *pnetdev, const char *ifname)
{

#ifdef CONFIG_EASY_REPLACEMENT
	_adapter *padapter = rtw_netdev_priv(pnetdev);
	struct net_device	*TargetNetdev = NULL;
	_adapter			*TargetAdapter = NULL;
	struct net 		*devnet = NULL;

	if(padapter->bDongle == 1)
	{
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,6,24))
		TargetNetdev = dev_get_by_name("wlan0");
#else
	#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,6,26))
		devnet = pnetdev->nd_net;
	#else
		devnet = dev_net(pnetdev);
	#endif
		TargetNetdev = dev_get_by_name(devnet, "wlan0");
#endif
		if(TargetNetdev) {
			DBG_871X("Force onboard module driver disappear !!!\n");
			TargetAdapter = rtw_netdev_priv(TargetNetdev);
			TargetAdapter->DriverState = DRIVER_DISAPPEAR;

			padapter->pid[0] = TargetAdapter->pid[0];
			padapter->pid[1] = TargetAdapter->pid[1];
			padapter->pid[2] = TargetAdapter->pid[2];
			
			dev_put(TargetNetdev);
			unregister_netdev(TargetNetdev);

			if(TargetAdapter->chip_type == padapter->chip_type)
				rtw_proc_remove_one(TargetNetdev);

			padapter->DriverState = DRIVER_REPLACE_DONGLE;
		}
	}
#endif

	if(dev_alloc_name(pnetdev, ifname) < 0)
	{
		RT_TRACE(_module_os_intfs_c_,_drv_err_,("dev_alloc_name, fail! \n"));
	}

//TODO
//	netif_carrier_off(pnetdev);
	//rtw_netif_stop_queue(pnetdev);

	return 0;
}

struct net_device *rtw_init_netdev(_adapter *old_padapter)	
{
	_adapter *padapter;
	struct net_device *pnetdev;

	RT_TRACE(_module_os_intfs_c_,_drv_info_,("+init_net_dev\n"));

	if(old_padapter != NULL) 
		pnetdev = rtw_alloc_etherdev_with_old_priv(sizeof(_adapter), (void *)old_padapter);
	else 
		pnetdev = rtw_alloc_etherdev(sizeof(_adapter));
	
	if (!pnetdev)
		return NULL;

	padapter = rtw_netdev_priv(pnetdev);
	padapter->pnetdev = pnetdev;	

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,24)
	SET_MODULE_OWNER(pnetdev);
#endif
	
	//pnetdev->init = NULL;
	
#if (LINUX_VERSION_CODE>=KERNEL_VERSION(2,6,29))
	DBG_871X("register rtw_netdev_ops to netdev_ops\n");
	pnetdev->netdev_ops = &rtw_netdev_ops;
#else
	pnetdev->open = netdev_open;
	pnetdev->stop = netdev_close;	
	pnetdev->hard_start_xmit = rtw_xmit_entry;
//TODO
//	pnetdev->set_mac_address = rtw_net_set_mac_address;
	pnetdev->get_stats = rtw_net_get_stats;
	pnetdev->do_ioctl = rtw_ioctl;
#endif


#ifdef CONFIG_TCP_CSUM_OFFLOAD_TX
	pnetdev->features |= NETIF_F_IP_CSUM;
#endif	
	//pnetdev->tx_timeout = NULL;
//TODO
//	pnetdev->watchdog_timeo = HZ*3; /* 3 second timeout */
#ifdef CONFIG_WIRELESS_EXT
	pnetdev->wireless_handlers = (struct iw_handler_def *)&rtw_handlers_def;
#endif

#ifdef WIRELESS_SPY
	//priv->wireless_data.spy_data = &priv->spy_data;
	//pnetdev->wireless_data = &priv->wireless_data;
#endif

	//step 2.
   	loadparam(padapter, pnetdev);
	
	return pnetdev;

}

int rtw_init_io_priv(_adapter *padapter, void (*set_intf_ops)(struct _io_ops *pops))
{
	if (set_intf_ops == NULL)
		return _FAIL;

	set_intf_ops(&padapter->iopriv.io_ops);

	return _SUCCESS;
}


/*
 * Do deinit job corresponding to netdev_open()
 */
static void rtw_dev_unload(PADAPTER padapter)
{
	RT_TRACE(_module_hci_intfs_c_, _drv_notice_, ("+rtw_dev_unload\n"));

	padapter->bDriverStopped = _TRUE;

	if (padapter->bup == _TRUE)
	{
		if (padapter->intf_stop)
			padapter->intf_stop(padapter);

		RT_TRACE(_module_hci_intfs_c_, _drv_notice_, ("@ rtw_dev_unload: stop intf complete!\n"));

		if (!padapter->pwrctrlpriv.bInternalAutoSuspend)
			rtw_stop_drv_threads(padapter);

		RT_TRACE(_module_hci_intfs_c_, _drv_notice_, ("@ rtw_dev_unload: stop thread complete!\n"));

		if (padapter->bSurpriseRemoved == _FALSE)
		{
#ifdef CONFIG_WOWLAN
			if (padapter->pwrctrlpriv.bSupportWakeOnWlan == _TRUE) {
				DBG_871X("%s bSupportWakeOnWlan==_TRUE  do not run rtw_hal_deinit()\n",__FUNCTION__);
			}
			else
#endif
			{
				rtw_hal_deinit(padapter);
			}
			padapter->bSurpriseRemoved = _TRUE;
		}
		RT_TRACE(_module_hci_intfs_c_, _drv_notice_, ("@ rtw_dev_unload: deinit hal complelt!\n"));

		padapter->bup = _FALSE;
	}
	else {
		RT_TRACE(_module_hci_intfs_c_, _drv_notice_, ("rtw_dev_unload: bup==_FALSE\n"));
	}

	RT_TRACE(_module_hci_intfs_c_, _drv_notice_, ("-rtw_dev_unload\n"));
}

#ifdef CONFIG_CONCURRENT_MODE
int _netdev_if2_open(struct net_device *pnetdev)
{	
	_adapter *padapter = (_adapter *)rtw_netdev_priv(pnetdev);
	_adapter *primary_padapter = padapter->pbuddy_adapter;

	DBG_871X("+871x_drv - if2_open, bup=%d\n", padapter->bup);

	if(primary_padapter->bup == _FALSE || primary_padapter->hw_init_completed == _FALSE)
	{
		_netdev_open(primary_padapter->pnetdev);
	}

	if(padapter->bup == _FALSE && primary_padapter->bup == _TRUE && 
		primary_padapter->hw_init_completed == _TRUE)
	{
//		int i;
	
		padapter->bDriverStopped = _FALSE;
	 	padapter->bSurpriseRemoved = _FALSE;	 
		padapter->bCardDisableWOHSM = _FALSE;
		

		rtw_memcpy(pnetdev->dev_addr, padapter->eeprompriv.mac_addr, ETH_ALEN); 


//		rtw_memcpy(padapter->HalData, primary_padapter->HalData, padapter->hal_data_sz);
		rtw_hal_clone_data(padapter, primary_padapter);

		padapter->bFWReady = primary_padapter->bFWReady;
		
		rtw_hal_set_hwreg(padapter, HW_VAR_MAC_ADDR, pnetdev->dev_addr);

		//if (init_mlme_ext_priv(padapter) == _FAIL)
		//	goto netdev_if2_open_error;	


		//if(rtw_start_drv_threads(padapter) == _FAIL)
		//{
		//	goto netdev_if2_open_error;		
		//}


		if(padapter->intf_start)
		{
			padapter->intf_start(padapter);
		}


		padapter->hw_init_completed = _TRUE;
		

		//padapter->dir_dev = NULL;
		//rtw_proc_init_one(pnetdev);
		padapter->bup = _TRUE;
		
	}

	padapter->net_closed = _FALSE;

	//_set_timer(&padapter->mlmepriv.dynamic_chk_timer, 2000);

	if(!rtw_netif_queue_stopped(pnetdev))
		rtw_netif_start_queue(pnetdev);
	else
		rtw_netif_wake_queue(pnetdev);

#ifdef CONFIG_P2P
	init_wifidirect_info( padapter, P2P_ROLE_DISABLE );
	reset_global_wifidirect_info( padapter );
#ifdef CONFIG_WFD
	if(rtw_init_wifi_display_info(padapter) == _FAIL)
	{
		RT_TRACE(_module_os_intfs_c_,_drv_err_,("\n Can't init init_wifi_display_info\n"));

		goto netdev_if2_open_error;
	}
#endif //CONFIG_WFD	
#endif // CONFIG_P2P	

	DBG_871X("-871x_drv - if2_open, bup=%d\n", padapter->bup);
	return 0;

#ifdef CONFIG_P2P
	netdev_if2_open_error:

	padapter->bup = _FALSE;
	
	//netif_carrier_off(pnetdev);	
	rtw_netif_stop_queue(pnetdev);
	
	return (-1);	
#endif
}

int netdev_if2_open(struct net_device *pnetdev)
{
	int ret;
	_adapter *padapter = (_adapter *)rtw_netdev_priv(pnetdev);
	
	rtw_enter_critical_mutex(padapter->hw_init_mutex, NULL);
	ret = _netdev_if2_open(pnetdev);
	rtw_exit_critical_mutex(padapter->hw_init_mutex, NULL);
	return ret;
}

static int netdev_if2_close(struct net_device *pnetdev)
{
	_adapter *padapter = (_adapter *)rtw_netdev_priv(pnetdev);

	padapter->net_closed = _TRUE;

	if(pnetdev)   
	{
		if (!rtw_netif_queue_stopped(pnetdev))
			rtw_netif_stop_queue(pnetdev);
	}

#ifdef CONFIG_IOCTL_CFG80211
	rtw_scan_abort(padapter);
	wdev_to_priv(padapter->rtw_wdev)->bandroid_scan = _FALSE;
#endif

	return 0;
}

#if (LINUX_VERSION_CODE>=KERNEL_VERSION(2,6,29))
static const struct net_device_ops rtw_netdev_if2_ops = {
	.ndo_open = netdev_if2_open,
        .ndo_stop = netdev_if2_close,
        .ndo_start_xmit = rtw_xmit_entry,
        .ndo_set_mac_address = rtw_net_set_mac_address,
        .ndo_get_stats = rtw_net_get_stats,
        .ndo_do_ioctl = rtw_ioctl,
#if (LINUX_VERSION_CODE>=KERNEL_VERSION(2,6,35))
	.ndo_select_queue	= rtw_select_queue,
#endif	
};
#endif

_adapter *rtw_drv_if2_init(_adapter *primary_padapter, char *name,
	void (*set_intf_ops)(struct _io_ops *pops))
{
//	int res = _FAIL;
	struct net_device *pnetdev;	
	_adapter *padapter = NULL;
	struct dvobj_priv *pdvobjpriv;
	u8 mac[ETH_ALEN];

	/****** init netdev ******/
	pnetdev = rtw_init_netdev(NULL);
	if (!pnetdev) 
		goto error_rtw_drv_if2_init;

#if (LINUX_VERSION_CODE>=KERNEL_VERSION(2,6,29))
	DBG_871X("register rtw_netdev_if2_ops to netdev_ops\n");
	pnetdev->netdev_ops = &rtw_netdev_if2_ops;
#else
	pnetdev->open = netdev_if2_open;
	pnetdev->stop = netdev_if2_close;		
#endif
	
#ifdef CONFIG_NO_WIRELESS_HANDLERS
	pnetdev->wireless_handlers = NULL;
#endif

	/****** init adapter ******/
	padapter = rtw_netdev_priv(pnetdev);
	rtw_memcpy(padapter, primary_padapter, sizeof(_adapter));
	rtw_memset(&padapter->mlmepriv, 0, sizeof(struct mlme_priv));
	padapter->mlmepriv.ChannelPlan = primary_padapter->mlmepriv.ChannelPlan;
	rtw_memset(&padapter->mlmeextpriv, 0, sizeof(struct mlme_ext_priv));
	rtw_memset(&padapter->stapriv, 0, sizeof(struct sta_priv));
	padapter->ph2c_fwcmd_mutex = primary_padapter->ph2c_fwcmd_mutex;
	padapter->psetch_mutex = primary_padapter->psetch_mutex;
	padapter->psetbw_mutex = primary_padapter->psetbw_mutex;
	padapter->hw_init_mutex = primary_padapter->hw_init_mutex;

	//
	padapter->bup = _FALSE;
	padapter->net_closed = _TRUE;
	padapter->hw_init_completed = _FALSE;


	//set adapter_type/iface type
	padapter->isprimary = _FALSE;
	padapter->adapter_type = SECONDARY_ADAPTER;
	padapter->pbuddy_adapter = primary_padapter;		
	padapter->iface_type = IFACE_PORT1;

	//
	padapter->pnetdev = pnetdev;

	/****** setup dvobj ******/
	pdvobjpriv = adapter_to_dvobj(padapter);
	pdvobjpriv->if2 = padapter;
	pdvobjpriv->padapters[pdvobjpriv->iface_nums++] = padapter;

	SET_NETDEV_DEV(pnetdev, dvobj_to_dev(pdvobjpriv));
	#ifdef CONFIG_IOCTL_CFG80211
	rtw_wdev_alloc(padapter, dvobj_to_dev(pdvobjpriv));
	#endif //CONFIG_IOCTL_CFG80211

	//set interface_type/chip_type/HardwareType
	padapter->interface_type = primary_padapter->interface_type;
#ifdef CONFIG_PROC_DEBUG	
	padapter->chip_type = primary_padapter->chip_type;
#endif
	padapter->HardwareType = primary_padapter->HardwareType;
	
	//step 2. hook HalFunc, allocate HalData
	hal_set_hal_ops(padapter);
	
	padapter->HalFunc.inirp_init = NULL;
	padapter->HalFunc.inirp_deinit = NULL;

	//	
	padapter->intf_start = primary_padapter->intf_start;
	padapter->intf_stop = primary_padapter->intf_stop;

	//step init_io_priv
	//if ((rtw_init_io_priv(padapter, set_intf_ops)) == _FAIL) {
	//	RT_TRACE(_module_hci_intfs_c_,_drv_err_,(" \n Can't init io_reqs\n"));
	//}

	//step read_chip_version
	rtw_hal_read_chip_version(padapter);

	//step usb endpoint mapping
	rtw_hal_chip_configure(padapter);


	//init drv data
	if(rtw_init_drv_sw(padapter)!= _SUCCESS)
		goto error_rtw_drv_if2_init;
	

	// alloc dev name after got efuse data.
	if(name == NULL)
		name = (char*)padapter->registrypriv.if2name;
	
	rtw_init_netdev_name(pnetdev, name);
	//get mac address from primary_padapter
	rtw_memcpy(mac, primary_padapter->eeprompriv.mac_addr, ETH_ALEN);
	
	if (((mac[0]==0xff) &&(mac[1]==0xff) && (mac[2]==0xff) &&
	     (mac[3]==0xff) && (mac[4]==0xff) &&(mac[5]==0xff)) ||
	    ((mac[0]==0x0) && (mac[1]==0x0) && (mac[2]==0x0) &&
	     (mac[3]==0x0) && (mac[4]==0x0) &&(mac[5]==0x0)))
	{
		mac[0] = 0x00;
		mac[1] = 0xe0;
		mac[2] = 0x4c;
		mac[3] = 0x87;
		mac[4] = 0x11;
		mac[5] = 0x22;
	}
	else
	{
		//If the BIT1 is 0, the address is universally administered. 
		//If it is 1, the address is locally administered
		mac[0] |= BIT(1); // locally administered
		
	}

	rtw_memcpy(padapter->eeprompriv.mac_addr, mac, ETH_ALEN);
	
	rtw_memcpy(pnetdev->dev_addr, mac, ETH_ALEN);

	DBG_871X("MAC Address (if2) = "MAC_FMT"\n", MAC_ARG(mac));

	primary_padapter->pbuddy_adapter = padapter;	

	//prepare concurrent shared data buffer
	if(!primary_padapter->pcodatapriv)
	{
		struct co_data_priv *pcodatapriv;
		
		pcodatapriv = (struct co_data_priv*)rtw_zvmalloc(sizeof(struct co_data_priv));

		primary_padapter->pcodatapriv = pcodatapriv;
		padapter->pcodatapriv = pcodatapriv;

		//concurrent shared data init.
		pcodatapriv->co_ch = rtw_channel;
		pcodatapriv->co_bw = CHANNEL_WIDTH_20;
		pcodatapriv->co_ch_offset = HAL_PRIME_CHNL_OFFSET_DONT_CARE;		
	}	
	
	/* Tell the network stack we exist */
	if (register_netdev(pnetdev) != 0) 
	{
		goto error_rtw_drv_if2_init;
	}
	
//	res = _SUCCESS;

	return padapter;

		
error_rtw_drv_if2_init:

	rtw_free_drv_sw(padapter);	

	if (pnetdev)
		rtw_free_netdev(pnetdev);

	return NULL;
	
}


void rtw_drv_if2_stop(_adapter *if2)
{
	_adapter *padapter = if2;
//	struct net_device *pnetdev = NULL;

	if (padapter == NULL)
		return;

	rtw_cancel_all_timer(padapter);

	if (padapter->bup == _TRUE) {
		padapter->bDriverStopped = _TRUE;
		
		while(padapter->cmdThread.callback_running == _TRUE || 
			rtw_is_list_empty(&padapter->pbuddy_adapter->cmdpriv.cmd_queue.queue) == _FALSE)
			rtw_mdelay_os(1);
			
		if (padapter->intf_stop)
		{
			padapter->intf_stop(padapter);
		}

		//rtw_stop_drv_threads(padapter);

		padapter->bup = _FALSE;
	}
}


void rtw_drv_if2_free(_adapter *primary_padapter)
{
	_adapter *padapter=NULL;
	struct net_device *pnetdev=NULL;
#ifdef CONFIG_IOCTL_CFG80211
	struct wireless_dev *wdev;
#endif //CONFIG_IOCTL_CFG80211

	if(primary_padapter && primary_padapter->adapter_type == PRIMARY_ADAPTER)
	{
		padapter = primary_padapter->pbuddy_adapter;
		//pnetdev = padapter->pnetdev;
	}

	if(padapter==NULL)
		return;
	DBG_871X("rtw_drv_if2_free\n\r");
	pnetdev = padapter->pnetdev;

#ifdef CONFIG_IOCTL_CFG80211
		wdev = padapter->rtw_wdev;
#endif //CONFIG_IOCTL_CFG80211

#ifdef CONFIG_AP_MODE
	free_mlme_ap_info(padapter);
	#ifdef CONFIG_HOSTAPD_MLME
	hostapd_mode_unload(padapter);
	#endif
#endif

	if(pnetdev) 
	{
		unregister_netdev(pnetdev); //will call netdev_close()
		//rtw_proc_remove_one(pnetdev);
	}
	
	primary_padapter->pbuddy_adapter = NULL;
	
	padapter->pcodatapriv = NULL;
	
	rtw_free_drv_sw(padapter);
#ifdef CONFIG_IOCTL_CFG80211
	rtw_wdev_free(wdev);
#endif //CONFIG_IOCTL_CFG80211

	rtw_free_netdev(pnetdev);

	//free concurrent shared data buffer
	if(primary_padapter->pcodatapriv)
	{
		rtw_vmfree((u8*)primary_padapter->pcodatapriv, sizeof(struct co_data_priv));

		primary_padapter->pcodatapriv = NULL;
	}

}
#endif //end of CONFIG_CONCURRENT_MODE

int _netdev_open(struct net_device *pnetdev)
{
	uint status;	
	_adapter *padapter = (_adapter *)rtw_netdev_priv(pnetdev);
	struct pwrctrl_priv *pwrctrlpriv = &padapter->pwrctrlpriv;

	RT_TRACE(_module_os_intfs_c_,_drv_info_,("+871x_drv - dev_open\n"));
	DBG_871X("+871x_drv - drv_open, bup=%d\n", padapter->bup);

	if(pwrctrlpriv->ps_flag == _TRUE){
		padapter->net_closed = _FALSE;
		goto netdev_open_normal_process;
	}

	if(padapter->bup == _FALSE)
	{
		padapter->bDriverStopped = _FALSE;
	 	padapter->bSurpriseRemoved = _FALSE;
		padapter->bCardDisableWOHSM = _FALSE;

		status = rtw_hal_init(padapter);
		if (status ==_FAIL)
		{			
			RT_TRACE(_module_os_intfs_c_,_drv_err_,("rtl871x_hal_init(): Can't init h/w!\n"));
			goto netdev_open_error;
		}
		
		DBG_871X("MAC Address = "MAC_FMT"\n", MAC_ARG(pnetdev->dev_addr));

		status=rtw_start_drv_threads(padapter);
		if(status ==_FAIL)
		{			
			RT_TRACE(_module_os_intfs_c_,_drv_err_,("Initialize driver software resource Failed!\n"));
			goto netdev_open_error;			
		}

		if (init_hw_mlme_ext(padapter) == _FAIL)
		{
			RT_TRACE(_module_os_intfs_c_,_drv_err_,("can't init mlme_ext_priv\n"));
			goto netdev_open_error;
		}

#ifdef CONFIG_DRVEXT_MODULE
		init_drvext(padapter);
#endif

		if(padapter->intf_start)
		{
			padapter->intf_start(padapter);
		}

#ifndef RTK_DMP_PLATFORM
		rtw_proc_init_one(pnetdev);
#endif

#ifdef CONFIG_IOCTL_CFG80211
		rtw_cfg80211_init_wiphy(padapter);
#endif

		rtw_led_control(padapter, LED_CTL_NO_LINK);

		padapter->bup = _TRUE;
	}
	padapter->net_closed = _FALSE;

#ifdef CONFIG_NEW_SIGNAL_STAT_PROCESS
	rtw_set_signal_stat_timer(&padapter->recvpriv);
#endif
	
	rtw_set_timer(&padapter->mlmepriv.dynamic_chk_timer, 2000);

	padapter->pwrctrlpriv.bips_processing = _FALSE;	
	rtw_set_pwr_state_check_timer(&padapter->pwrctrlpriv);

	//netif_carrier_on(pnetdev);//call this func when rtw_joinbss_event_callback return success
	if(!rtw_netif_queue_stopped(pnetdev))
		rtw_netif_start_queue(pnetdev);
	else
		rtw_netif_wake_queue(pnetdev);

#ifdef CONFIG_BR_EXT
	netdev_br_init(pnetdev);
#endif	// CONFIG_BR_EXT

#ifdef CONFIG_P2P
	init_wifidirect_info( padapter, P2P_ROLE_DISABLE );
	reset_global_wifidirect_info( padapter );
#ifdef CONFIG_WFD
	if(rtw_init_wifi_display_info(padapter) == _FAIL)
	{
		RT_TRACE(_module_os_intfs_c_,_drv_err_,("\n Can't init init_wifi_display_info\n"));

		goto netdev_open_error;
	}
#endif //CONFIG_WFD	
#endif // CONFIG_P2P

netdev_open_normal_process:

	#ifdef CONFIG_CONCURRENT_MODE
	{
		_adapter *sec_adapter = padapter->pbuddy_adapter;
		if(sec_adapter && (sec_adapter->bup == _FALSE || sec_adapter->hw_init_completed == _FALSE))
			_netdev_if2_open(sec_adapter->pnetdev);
	}
	#endif

	RT_TRACE(_module_os_intfs_c_,_drv_info_,("-871x_drv - dev_open\n"));
	DBG_871X("-871x_drv - drv_open, bup=%d\n", padapter->bup);
	//Used by FAST RECONNECTION
	if(p_init_done_callback)
		p_init_done_callback();
	return 0;
	
netdev_open_error:

	padapter->bup = _FALSE;
//TODO	
//	netif_carrier_off(pnetdev);	
	rtw_netif_stop_queue(pnetdev);
	
	RT_TRACE(_module_os_intfs_c_,_drv_err_,("-871x_drv - dev_open, fail!\n"));
	DBG_871X("-871x_drv - drv_open fail, bup=%d\n", padapter->bup);
	
	return (-1);
	
}

int netdev_open(struct net_device *pnetdev)
{
	int ret;
	_adapter *padapter = (_adapter *)rtw_netdev_priv(pnetdev);
	
	rtw_enter_critical_mutex(padapter->hw_init_mutex, NULL);
	ret = _netdev_open(pnetdev);
	rtw_exit_critical_mutex(padapter->hw_init_mutex, NULL);

	return ret;
}

static int netdev_close(struct net_device *pnetdev)
{
	_adapter *padapter = (_adapter *)rtw_netdev_priv(pnetdev);

	RT_TRACE(_module_os_intfs_c_,_drv_info_,("+871x_drv - drv_close\n"));	

	if(padapter->pwrctrlpriv.bInternalAutoSuspend == _TRUE)
	{
		//rtw_pwr_wakeup(padapter);
		if(padapter->pwrctrlpriv.rf_pwrstate == rf_off)
			padapter->pwrctrlpriv.ps_flag = _TRUE;
	}
	padapter->net_closed = _TRUE;

/*	if(!padapter->hw_init_completed)
	{
		DBG_871X("(1)871x_drv - drv_close, bup=%d, hw_init_completed=%d\n", padapter->bup, padapter->hw_init_completed);

		padapter->bDriverStopped = _TRUE;

		rtw_dev_unload(padapter);
	}
	else*/
	if(padapter->pwrctrlpriv.rf_pwrstate == rf_on){
		DBG_871X("(2)871x_drv - drv_close, bup=%d, hw_init_completed=%d\n", padapter->bup, padapter->hw_init_completed);

		//s1.
		if(pnetdev)   
		{
			if (!rtw_netif_queue_stopped(pnetdev))
				rtw_netif_stop_queue(pnetdev);
		}

#ifndef CONFIG_ANDROID
		//s2.	
		//s2-1.  issue rtw_disassoc_cmd to fw
		rtw_disassoc_cmd(padapter);	
		//s2-2.  indicate disconnect to os
		rtw_indicate_disconnect(padapter);
		//s2-3. 
		rtw_free_assoc_resources(padapter, 1);
		//s2-4.
		rtw_free_network_queue(padapter,_TRUE);
#endif
		// Close LED
		rtw_led_control(padapter, LED_CTL_POWER_OFF);
	}

#ifdef CONFIG_BR_EXT
	//if (OPMODE & (WIFI_STATION_STATE | WIFI_ADHOC_STATE)) 
	{
		//void nat25_db_cleanup(_adapter *priv);
		nat25_db_cleanup(padapter);
	}
#endif	// CONFIG_BR_EXT

#ifdef CONFIG_P2P
	#ifdef CONFIG_IOCTL_CFG80211
	if(wdev_to_priv(padapter->rtw_wdev)->p2p_enabled == _TRUE)
		wdev_to_priv(padapter->rtw_wdev)->p2p_enabled = _FALSE;
	#endif
	rtw_p2p_enable(padapter, P2P_ROLE_DISABLE);
#endif //CONFIG_P2P

#ifdef CONFIG_IOCTL_CFG80211
	rtw_scan_abort(padapter);
	wdev_to_priv(padapter->rtw_wdev)->bandroid_scan = _FALSE;
	padapter->rtw_wdev->iftype = NL80211_IFTYPE_MONITOR; //set this at the end
#endif //CONFIG_IOCTL_CFG80211

#ifdef CONFIG_WAPI_SUPPORT
	rtw_wapi_disable_tx(padapter);
#endif

	RT_TRACE(_module_os_intfs_c_,_drv_info_,("-871x_drv - drv_close\n"));
	DiagPrintf("-871x_drv - drv_close, bup=%d\n", padapter->bup);

	return 0;
	
}

static PADAPTER rtw_if1_init(struct dvobj_priv *dvobj, rtw_mode_t mode)
{
	int status = _FAIL;
	struct net_device *pnetdev;
	PADAPTER padapter = NULL;

	padapter = (PADAPTER)rtw_zvmalloc(sizeof(*padapter));
	if (NULL == padapter) {
		goto exit;
	}

	padapter->dvobj = dvobj;
	dvobj->if1 = (void*)padapter;

	padapter->bDriverStopped = _TRUE;
	
	padapter->hw_init_mutex = &drvpriv.hw_init_mutex;
#ifdef CONFIG_CONCURRENT_MODE
	//set global variable to primary adapter
	padapter->ph2c_fwcmd_mutex = &drvpriv.h2c_fwcmd_mutex;
	padapter->psetch_mutex = &drvpriv.setch_mutex;
	padapter->psetbw_mutex = &drvpriv.setbw_mutex;

	padapter->isprimary = _TRUE;
	padapter->adapter_type = PRIMARY_ADAPTER;
	dvobj->padapters[dvobj->iface_nums++] = (void*)padapter;
	padapter->iface_type = IFACE_PORT0;
#endif
	padapter->work_mode = mode;

	padapter->interface_type = (u16) hci_bus_intf_type;
	decide_chip_type_by_device_id(padapter);

	//3 1. init network device data
	pnetdev = rtw_init_netdev(padapter);
	if (!pnetdev)
		goto free_adapter;

	SET_NETDEV_DEV(pnetdev, dvobj_to_dev(dvobj));

#ifdef CONFIG_IOCTL_CFG80211
	rtw_wdev_alloc(padapter, dvobj_to_dev(dvobj));
#endif

	//3 2. Initialize I/O operation for different bus interface
	if (rtw_init_io_priv(padapter, hci_set_intf_ops) == _FAIL)
	{
		RT_TRACE(_module_hci_intfs_c_, _drv_err_,
			("%s: Can't init io_priv\n", __FUNCTION__));
		goto free_adapter;
	}

	//3 3. init driver special setting, interface, OS and hardware relative
	if(hal_set_hal_ops(padapter) == _FAIL)
		goto free_hal_data;

	//3 4. The most first initial hardware setting for different bus interface
	rtw_hal_chip_configure(padapter);

	//3 5. initialize Chip version	
	rtw_hal_read_chip_version(padapter);	

	//3 6. read efuse/eeprom data
	rtw_hal_read_chip_info(padapter);

	//3 7. Initialize bus start/stop operation
	padapter->intf_start = &hci_intf_start;
	padapter->intf_stop = &hci_intf_stop;

	//3 8. Initialize t/rx transmit resources
	if(rtw_hal_inirp_init(padapter) ==_FAIL) {
		RT_TRACE(_module_hci_intfs_c_,_drv_err_,("Initialize PCI desc ring Failed!\n"));
		goto free_hal_data;
	}

	//3 9. Disable interrupt before software init
	rtw_hal_disable_interrupt(padapter);

	//3 10. Init driver common data
	if (rtw_init_drv_sw(padapter) == _FAIL) {
		RT_TRACE(_module_hci_intfs_c_, _drv_err_,
			 ("%s: Initialize driver software resource Failed!\n", __FUNCTION__));		
		goto wifi_drv_init_err;
	}
	
#ifndef CONFIG_WLAN_HAL_TEST
 
	//3 11. get WLan MAC address
	// alloc dev name after read efuse.
	rtw_init_netdev_name(pnetdev, (const char*)padapter->registrypriv.ifname); 
	rtw_macaddr_cfg(padapter->eeprompriv.mac_addr);
	rtw_memcpy(pnetdev->dev_addr, padapter->eeprompriv.mac_addr, ETH_ALEN);
#endif
	
	DBG_871X("bDriverStopped:%d, bSurpriseRemoved:%d, bup:%d, hw_init_completed:%d\n"
		,padapter->bDriverStopped
		,padapter->bSurpriseRemoved
		,padapter->bup
		,padapter->hw_init_completed
	);

#ifdef CONFIG_HOSTAPD_MLME
	hostapd_mode_init(padapter);
#endif

	status = _SUCCESS;

wifi_drv_init_err:
	// This code section can be executed only if rtw_init_drv_sw is executed
	if (status != _SUCCESS) {
		padapter->bDriverStopped = _TRUE;
		rtw_drv_deinit(padapter);
	}

free_hal_data:
	if (status != _SUCCESS && padapter->HalData)
		rtw_mfree(padapter->HalData, sizeof(padapter->hal_data_sz));

//free_wdev:
	if (status != _SUCCESS) {
		#ifdef CONFIG_IOCTL_CFG80211
		rtw_wdev_free(padapter->rtw_wdev);
		#endif
	}

free_adapter:
	if (status != _SUCCESS) {
		if (pnetdev)
			rtw_free_netdev(pnetdev);
		else if (padapter)
			rtw_vmfree((u8*)padapter, sizeof(*padapter));
		padapter = NULL;
	}
exit:
	return padapter;
}

static void rtw_if1_deinit(PADAPTER if1)
{
	struct net_device *pnetdev = if1->pnetdev;
	struct mlme_priv *pmlmepriv = &if1->mlmepriv;


#if defined(CONFIG_HAS_EARLYSUSPEND ) || defined(CONFIG_ANDROID_POWER)
	rtw_unregister_early_suspend(&if1->pwrctrlpriv);
#endif
	
	//rtw_pm_set_ips(if1, IPS_NONE);
	//rtw_pm_set_lps(if1, PS_MODE_ACTIVE);

	//LeaveAllPowerSaveMode(if1);

	if (check_fwstate(pmlmepriv, _FW_LINKED))
		disconnect_hdl(if1, NULL);

#ifdef CONFIG_AP_MODE
	free_mlme_ap_info(if1);
	#ifdef CONFIG_HOSTAPD_MLME
	hostapd_mode_unload(if1);
#endif
#endif

//TODO
#if 0
	if(if1->DriverState != DRIVER_DISAPPEAR) {
		if(pnetdev) {
			unregister_netdev(pnetdev); //will call netdev_close()
			rtw_proc_remove_one(pnetdev);
				}
			}
#else
	pnetdev->stop(pnetdev);
#endif	//#if 0
	rtw_cancel_all_timer(if1);

	rtw_dev_unload(if1);
	DBG_871X("+rtw_if1_deinit, hw_init_completed=%d\n", if1->hw_init_completed);
//TODO
//	rtw_handle_dualmac(if1, 0);

#ifdef CONFIG_IOCTL_CFG80211
	rtw_wdev_free(if1->rtw_wdev);
#endif

	rtw_hal_inirp_deinit(if1);
	rtw_free_drv_sw(if1);

	if(pnetdev)
		rtw_free_netdev(pnetdev);
}

/*
 * drv_init() - a device potentially for us
 *
 * notes: drv_init() is called when the bus driver has located a card for us to support.
 *        We accept the new device by returning 0.
 */
struct net_device *rtw_drv_probe(struct net_device* parent_dev, u32 mode)
{
	int status = _FAIL;
	struct dvobj_priv *dvobj;
	struct net_device *pnetdev;
	PADAPTER if1 = NULL;
#ifdef CONFIG_CONCURRENT_MODE
	PADAPTER if2 = NULL;
#endif
	DBG_871X("RTW: %s line:%d\n", __FUNCTION__, __LINE__);

	//Case of WLAN1_IDX 
	if(parent_dev){
		if1 =  (PADAPTER)rtw_netdev_priv(parent_dev);
		dvobj = if1->dvobj;
		goto if2_init;
	}

	// Case of WLAN0_IDX
	if ((dvobj = hci_dvobj_init()) == NULL) {
		DBG_871X("%s: Initialize device object priv Failed!\n", __FUNCTION__);
		goto exit;
	}

	if ((if1 = rtw_if1_init(dvobj, (rtw_mode_t)mode)) == NULL) {
		DBG_871X("rtw_init_primary_adapter Failed!\n");
		goto free_dvobj;
	}

	//Register Interrupt
	hci_dvobj_request_irq(dvobj);

	pnetdev = if1->pnetdev;
	status = _SUCCESS;
	RT_TRACE(_module_hci_intfs_c_,_drv_err_,("-871x_drv -if1 drv_init, success!\n"));
	goto exit;

if2_init:	
#ifdef CONFIG_CONCURRENT_MODE
	if ((if2 = rtw_drv_if2_init(if1, (char*)if1->registrypriv.if2name,NULL)) == NULL) {
		status = _FAIL;
		goto free_if1;
	}
	pnetdev = if2->pnetdev;
	RT_TRACE(_module_hci_intfs_c_,_drv_err_,("-871x_drv - if2 drv_init, success!\n"));
#endif

	status = _SUCCESS;

#ifdef CONFIG_CONCURRENT_MODE
free_if1:
#endif
	if (status != _SUCCESS && if1) {
		rtw_if1_deinit(if1);
	}

free_dvobj:
	if (status != _SUCCESS)
		hci_dvobj_deinit(dvobj);

exit:
	return ((status == _SUCCESS) ? pnetdev:NULL);
}

int rtw_dev_remove(struct net_device *pnetdev)
{
	PADAPTER padapter = (PADAPTER) rtw_netdev_priv(pnetdev);

_func_enter_;

	RT_TRACE(_module_hci_intfs_c_, _drv_notice_, ("+rtw_dev_remove\n"));
	hci_dvobj_free_irq(padapter->dvobj);
	
	rtw_pm_set_ips(padapter, IPS_NONE);
	rtw_pm_set_lps(padapter, PS_MODE_ACTIVE);

	LeaveAllPowerSaveMode(padapter);
#ifdef CONFIG_CONCURRENT_MODE
	rtw_drv_if2_stop(padapter->pbuddy_adapter);
	rtw_drv_if2_free(padapter);
#endif	
	rtw_if1_deinit(padapter);
	hci_dvobj_deinit(padapter->dvobj);

	RT_TRACE(_module_hci_intfs_c_, _drv_notice_, ("-rtw_dev_remove\n"));

_func_exit_;

	return 0;
}

void rtw_drv_entry(void)
{
	RT_TRACE(_module_hci_intfs_c_, _drv_notice_, ("+rtw_drv_entry\n"));
	DBG_8192C("RTW: rtw_drv_entry enter\n");


	rtw_mutex_init(&drvpriv.hw_init_mutex);
#if defined(CONFIG_CONCURRENT_MODE)
	//init global variable
	rtw_mutex_init(&drvpriv.h2c_fwcmd_mutex);
	rtw_mutex_init(&drvpriv.setch_mutex);
	rtw_mutex_init(&drvpriv.setbw_mutex);
#endif

	drvpriv.drv_registered = _TRUE;

#if (defined CONFIG_GSPI_HCI || defined CONFIG_SDIO_HCI)
	Set_WLAN_Power_On();
#endif

	DBG_8192C("RTW: rtw_drv_entry exit\n");

}

void rtw_drv_halt(void)
{
	RT_TRACE(_module_hci_intfs_c_, _drv_notice_, ("+rtw_drv_halt\n"));
	DBG_8192C("RTW: rtw_drv_halt enter\n");
//TODO
//	rtw_suspend_lock_uninit();
	drvpriv.drv_registered = _FALSE;

	rtw_mutex_free(&drvpriv.hw_init_mutex);
#if defined(CONFIG_CONCURRENT_MODE)
	rtw_mutex_free(&drvpriv.h2c_fwcmd_mutex);
	rtw_mutex_free(&drvpriv.setch_mutex);
	rtw_mutex_free(&drvpriv.setbw_mutex);
#endif


#if (defined CONFIG_GSPI_HCI || defined CONFIG_SDIO_HCI)
	Set_WLAN_Power_Off();
#endif

	DBG_8192C("RTW: rtw_drv_halt exit\n");
	RT_TRACE(_module_hci_intfs_c_, _drv_notice_, ("-rtw_drv_halt\n"));
}

//TODO
//module_init(rtw_drv_entry);
//module_exit(rtw_drv_halt);

#endif

