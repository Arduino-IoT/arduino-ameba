#include <_syslist.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/unistd.h>
#include "config.h"
#include "../rom/rom_libgloss_retarget.h"

#include <rtl_lib.h>

const char __stdin_name[]  = "/stdin";
const char __stdout_name[] = "/stdout";
const char __stderr_name[] = "/stderr";

extern struct _rom_libgloss_ram_map rom_libgloss_ram_map;


#undef dbg_printf
#if 0
#define dbg_printf DiagPrinf
#else
#define dbg_printf(x, ...) 
#endif

//--------------------------------------------------------------------------
int ram_libgloss_close(int fildes)
{
	__rtl_errno = ENOSYS;
	dbg_printf("%s \n", __FUNCTION__);
	return -1;
}

//--------------------------------------------------------------------------
int ram_libgloss_fstat(int fildes , struct stat *st)
{
	dbg_printf("%s \n", __FUNCTION__);
    if ((STDOUT_FILENO == fildes) || (STDERR_FILENO == fildes) || (STDIN_FILENO == fildes)) {
        st->st_mode = S_IFCHR;
        dbg_printf("%s 0\n", __FUNCTION__);
        return  0;
    }
    __rtl_errno = EBADF;
    dbg_printf("%s -1\n", __FUNCTION__);
    return -1;
}

//--------------------------------------------------------------------------
// if the file is a kind of terminal 
//
int ram_libgloss_isatty(int file)
{
//  errno = ENOSYS;
//  return 0;
	dbg_printf("%s \n", __FUNCTION__);
	 /* stdin, stdout and stderr should be tty */
	if (file < 3){
		dbg_printf("%s 1\n", __FUNCTION__);
		return 1;
	}
//    FileHandle* fhc = filehandles[fh-3];
//    if (fhc == NULL){
    	dbg_printf("%s -1\n", __FUNCTION__);
    	return -1;
//	}
//    return fhc->isatty();
}

//--------------------------------------------------------------------------
int ram_libgloss_lseek(int file , int ptr , int dir)
{
	__rtl_errno = ENOSYS;
	dbg_printf("%s \n", __FUNCTION__);
	return -1;
}

extern _LONG_CALL_ u8
prvStrCmp(
    IN  const   u8  *string1,
    IN  const   u8  *string2);


//--------------------------------------------------------------------------
int ram_libgloss_open(char *file , int flags , int mode)
{
//  errno = ENOSYS;
//  return -1;
	dbg_printf("%s \n", __FUNCTION__);
	if (rtl_strcmp(file, __stdin_name) == 0) {
        dbg_printf("%s 0\n", __FUNCTION__);
        return 0;
    } else if (rtl_strcmp(file, __stdout_name) == 0) {
        dbg_printf("%s 1\n", __FUNCTION__);
        return 1;
    } else if (rtl_strcmp(file, __stderr_name) == 0) {
        dbg_printf("%s 2\n", __FUNCTION__);
        return 2;
    }
    dbg_printf("%s -1\n", __FUNCTION__);
    return -1;
}

//--------------------------------------------------------------------------
int ram_libgloss_read(int file , char *ptr , int len)
{
	__rtl_errno = ENOSYS;
	dbg_printf("%s \n", __FUNCTION__);
	return -1;
}


extern _LONG_CALL_ void HalSerialPutcRtl8195a(const u8 c);

//--------------------------------------------------------------------------
int ram_libgloss_write(int file , const char *ptr , int len)
{
	int i, n;
//	errno = ENOSYS;
	dbg_printf("%s \n", __FUNCTION__);
	for (i = 0; i < len; i++) {
		HalSerialPutcRtl8195a(ptr[i]);
	}
	n = len;
	return n;
}

//--------------------------------------------------------------------------
void* ram_libgloss_sbrk(int incr)
{ 
	extern char   end; /* Set by linker.  */
	static char * heap_end; 
	char *        prev_heap_end; 

	if (heap_end == 0)
		heap_end = & end; 

	prev_heap_end = heap_end; 
	heap_end += incr; 

	dbg_printf("end = %x, incr = %d\n", heap_end, incr);
	return (void *) prev_heap_end; 
} 

//--------------------------------------------------------------------------
void init_rom_libgloss_ram_map(void)
{
	rom_libgloss_ram_map.libgloss_close = ram_libgloss_close;
	rom_libgloss_ram_map.libgloss_fstat = ram_libgloss_fstat;
	rom_libgloss_ram_map.libgloss_isatty = ram_libgloss_isatty;
	rom_libgloss_ram_map.libgloss_lseek = ram_libgloss_lseek;
	rom_libgloss_ram_map.libgloss_open = ram_libgloss_open;
	rom_libgloss_ram_map.libgloss_read = ram_libgloss_read;
	rom_libgloss_ram_map.libgloss_write = ram_libgloss_write;
	rom_libgloss_ram_map.libgloss_sbrk = ram_libgloss_sbrk;
}

//--------------------------------------------------------------------------
#if 1

#include <basic_types.h>

// TODO: 
// need to modify the code when _close_r move into the ROM

extern _LONG_CALL_ int __rtl_close_v1_00(int fildes);
extern _LONG_CALL_ int __rtl_fstat_v1_00(int fildes , struct stat *st);
extern _LONG_CALL_ int __rtl_isatty_v1_00(int file);
extern _LONG_CALL_ int __rtl_lseek_v1_00(int file , int ptr , int dir);
extern _LONG_CALL_ int __rtl_open_v1_00(char *file , int flags , int mode);
extern _LONG_CALL_ int __rtl_read_v1_00(int file , char *ptr , int len);
extern _LONG_CALL_ int __rtl_write_v1_00(int file , const char *ptr , int len);
extern _LONG_CALL_ void* __rtl_sbrk_v1_00(int incr);


/*
extern int _close(int fildes);
extern int _fstat(int fildes , struct stat *st);
extern int _isatty(int file);
extern int _lseek(int file , int ptr , int dir);
extern int _open(char *file , int flags , int mode);
extern int _read(int file , char *ptr , int len);
extern int _write(int file , char *ptr , int len);
extern void* _sbrk(int incr);



int _close(int fildes) 
{
    return __rtl_close_v1_00(fildes);
}

int _fstat(int fildes , struct stat *st)
{
	return __rtl_fstat_v1_00(fildes, st);
}


int _isatty(int file)
{
	return __rtl_isatty_v1_00(file);
}

int _lseek(int file , int ptr , int dir)
{
	return __rtl_lseek_v1_00(file, ptr, dir);
}

int _open(char *file , int flags , int mode)
{
	return __rtl_open_v1_00(file, flags, mode);
}

int _read(int file , char *ptr , int len)
{
	return __rtl_read_v1_00(file, ptr, len);
}

int _write(int file , char *ptr , int len)
{
	return __rtl_write_v1_00(file, ptr, len);
}

void* _sbrk(int incr)
{
	return __rtl_sbrk_v1_00(incr);
}
*/

#endif

