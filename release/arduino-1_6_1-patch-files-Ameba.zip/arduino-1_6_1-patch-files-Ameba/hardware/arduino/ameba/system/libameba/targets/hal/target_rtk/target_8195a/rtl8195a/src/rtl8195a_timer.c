/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2013 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */
#include "rtl8195a.h" 
#include "rtl8195a_timer.h"

u32
HalTimerReadCountRamRtl8195a(
    IN  u32 TimerId
)
{
    u32 TimerCountOld;
    u32 TimerCountNew;
    u32 TimerRDCnt;
    
    TimerRDCnt = 0;
    TimerCountOld = HAL_TIMER_READ32(TimerId*TIMER_INTERVAL + TIMER_CURRENT_VAL_OFF);
    while(1) {        
        TimerCountNew = HAL_TIMER_READ32(TimerId*TIMER_INTERVAL + TIMER_CURRENT_VAL_OFF);

        if (TimerCountOld == TimerCountNew) {
            return (u32)TimerCountOld;
        }
        else {
            TimerRDCnt++;
            TimerCountOld = TimerCountNew;

            if (TimerRDCnt >= 2){
                return (u32)TimerCountOld;
            }
        }
    }    
}
