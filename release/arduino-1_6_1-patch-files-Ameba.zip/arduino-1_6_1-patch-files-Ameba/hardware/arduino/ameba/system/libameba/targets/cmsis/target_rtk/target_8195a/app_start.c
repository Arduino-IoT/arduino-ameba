/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2013 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */

#include "rtl8195a.h"
#include "build_info.h"
#ifdef PLATFORM_FREERTOS
#include "FreeRTOS.h"
#include "task.h"
#endif

#if defined(CONFIG_SDIO_DEVICE_EN) && defined(CONFIG_SDIO_DEVICE_NORMAL)
extern VOID HalSdioInit(VOID);
#endif

#if defined(CONFIG_WIFI_NORMAL) && defined(CONFIG_NETWORK)
extern void init_rom_wlan_ram_map(void);
extern VOID wlan_network(VOID);
#endif

//3 Monitor App Function
extern VOID RtlConsolInitRam(u32 Boot, u32 TBLSz, VOID *pTBL);
#ifndef CONFIG_KERNEL
extern VOID RtlConsolTaskRom(VOID *Data);
#endif

#ifndef CONFIG_WITHOUT_MONITOR
extern COMMAND_TABLE    UartLogRamCmdTable[];
extern u32 GetRamCmdNum(VOID);
extern VOID UartLogIrqHandleRam(VOID * Data);
#endif

//NeoJou
#if 1
//#ifdef CONFIG_APP_DEMO
#define MAIN_APP_DEFAULT_STACK_SIZE         2048
#define MAIN_APP_DEFAULT_PRIORITY           (tskIDLE_PRIORITY + 1)
#endif

#ifdef CONFIG_MBED_ENABLED
extern void __libc_fini_array (void);
extern void __libc_init_array (void);
extern  void SVC_Handler (void);
extern  void PendSV_Handler (void);
extern  void SysTick_Handler (void);
#endif

static 
VOID
ReRegisterPlatformLogUart(
    VOID
)
{
    IRQ_HANDLE          UartIrqHandle;
    
    //4 Register Log Uart Callback function
    UartIrqHandle.Data = NULL;//(u32)&UartAdapter;
    UartIrqHandle.IrqNum = UART_LOG_IRQ;
    UartIrqHandle.IrqFun = (IRQ_FUN) UartLogIrqHandleRam;
    UartIrqHandle.Priority = 0;

    
    //4 Register Isr handle
    InterruptUnRegister(&UartIrqHandle); 
    InterruptRegister(&UartIrqHandle); 
//NeoJou
#if 0
#if !TASK_SCHEDULER_DISABLED    
    RtlConsolInitRam((u32)RAM_STAGE,(u32)GetRamCmdNum(),(VOID*)&UartLogRamCmdTable);
#else
    RtlConsolInitRam((u32)ROM_STAGE,(u32)GetRamCmdNum(),(VOID*)&UartLogRamCmdTable);
#endif
#endif
}

VOID ShowRamBuildInfo(VOID)
{
    
    DBG_8195A("=========================================================\n\n");
    //DBG_8195A("Build Time: "UTS_VERSION"\n");
    DBG_8195A("Build Time: "RTL8195AFW_COMPILE_TIME"\n");
    DBG_8195A("Build Author: "RTL8195AFW_COMPILE_BY"\n");    
    DBG_8195A("Build Host: "RTL8195AFW_COMPILE_HOST"\n");    
    DBG_8195A("Build ToolChain Version: "RTL195AFW_COMPILER"\n\n");    
    DBG_8195A("=========================================================\n");

}


extern int main( void );

#ifdef PLATFORM_RTX
extern  void SVC_Handler (void);
extern  void PendSV_Handler (void);
extern  void SysTick_Handler (void);
#endif


void main_console(void)
{
    ReRegisterPlatformLogUart();            
	RtlConsolInitRam((u32)RAM_STAGE,(u32)GetRamCmdNum(),(VOID*)&UartLogRamCmdTable);
}


// The Main App entry point
void _AppStart(void)
{
#ifdef PLATFORM_RTX
    InterruptForOSInit((VOID*)SVC_Handler,
                       (VOID*)PendSV_Handler,
                       (VOID*)SysTick_Handler);
    __asm (
        "ldr   r0, =SystemInit\n"
        "blx   r0\n"
        "ldr   r0, =_start\n"
        "bx    r0\n"
    );

    DiagPrintf("OS system finished\n");
#else
    
    main_console();
    
#endif  // end of else of "#ifdef CONFIG_MBED_ENABLED"

}
