/******************************************************************************
 *
 * Copyright(c) 2007 - 2012 Realtek Corporation. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110, USA
 *
 *
 ******************************************************************************/

#ifndef __WIFI_INTFS_H_
#define __WIFI_INTFS_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "wifi_odm.h"

typedef enum 
{
	TEST_CHIP 		=	0,
	NORMAL_CHIP 	=	1,
	FPGA			=	2,
} HAL_CHIP_TYPE_E;

typedef enum 
{
	A_CUT_VERSION 		=	0,
	B_CUT_VERSION 		=	1,
	C_CUT_VERSION 		=	2,
	D_CUT_VERSION 		=	3,
	E_CUT_VERSION 		=	4,
	F_CUT_VERSION 		=	5,
	G_CUT_VERSION 		=	6,
	H_CUT_VERSION 		=	7,	
	I_CUT_VERSION 		=	8,
	J_CUT_VERSION 		=	9,
	K_CUT_VERSION 		=	10,
}HAL_CUT_VERSION_E;

typedef enum 
{
	CHIP_VENDOR_TSMC 	=	0,
	CHIP_VENDOR_UMC 	=	1,
	CHIP_VENDOR_SMIC 	=	2,
}HAL_VENDOR_E;

typedef enum {
	RT_SWITCHING_REGULATOR 	= 0,
	RT_LDO_REGULATOR 			= 1,
} RT_REGULATOR_MODE;


#define	RF_PATH_MAX		2				// Max 4 for ss larger than 2
#define MAX_RF_PATH		RF_PATH_MAX

#define CHANNEL_MAX_NUMBER		14	// 14 is the max channel number

#define 	MAX_TX_COUNT				4


typedef	struct RTW_WIFI_HAL_DATA_struct
{
	HAL_CHIP_TYPE_E		ChipType;
	HAL_CUT_VERSION_E	CUTVersion;
	HAL_VENDOR_E		VendorType;
	RT_REGULATOR_MODE	RegulatorMode; // switching regulator or LDO

	u8	Index24G_CCK_Base[MAX_RF_PATH][CHANNEL_MAX_NUMBER];
	u8	Index24G_BW40_Base[MAX_RF_PATH][CHANNEL_MAX_NUMBER];
	//If only one tx, only BW20 and OFDM are used.
	s8	CCK_24G_Diff[MAX_RF_PATH][MAX_TX_COUNT];	
	s8	OFDM_24G_Diff[MAX_RF_PATH][MAX_TX_COUNT];
	s8	BW20_24G_Diff[MAX_RF_PATH][MAX_TX_COUNT];
	s8	BW40_24G_Diff[MAX_RF_PATH][MAX_TX_COUNT];

	// status
	u8 bMacPwrCtrlOn;

	
	DM_ODM_T 		odmpriv;
	
} RTW_WIFI_HAL_DATA;


extern void rtw_wifi_init(RTW_WIFI_HAL_DATA *pHalData);
extern void rtw_read_chip_version(RTW_WIFI_HAL_DATA *pHalData);
extern void rtw_power_on(RTW_WIFI_HAL_DATA *pHalData);
extern void rtw_read_efuse(RTW_WIFI_HAL_DATA *pHalData);
extern void rtw_hal_dm_init(RTW_WIFI_HAL_DATA *pHalData);
extern void rtw_disable_interrupt(void);


#ifdef __cplusplus
}
#endif



#endif	//__wifi_INTFS_H_

