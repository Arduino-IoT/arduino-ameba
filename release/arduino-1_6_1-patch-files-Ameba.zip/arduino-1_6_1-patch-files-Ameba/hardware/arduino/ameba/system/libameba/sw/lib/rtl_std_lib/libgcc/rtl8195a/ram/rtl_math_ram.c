/******************************************************************************
 *
 * Copyright(c) 2007 - 2014 Realtek Corporation. All rights reserved.
 *                                        
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110, USA
 *
 *
 ******************************************************************************/

#include <rtl_math.h>
#include <rtl_math_rom.h>

#include <rtl_lib.h>

float rtl_fabsf(float a)
{
	return __rtl_fabsf(a);
}

double rtl_fabs(double a)
{
	return __rtl_fabs(a);
}

float rtl_cos_f32(float a) 
{
	return __rtl_cos_f32(a);
}

float rtl_sin_f32(float a) 
{
	return __rtl_sin_f32(a);
}

#if 0
void rtl_mult_f32_array(
		float * pSrcA, float * pSrcB,
		float * pDst, u32 blockSize)
{
	return __rtl_mult_f32_array(pSrcA, pSrcB, pDst, blockSize);
}
#endif

